# Feature matrix — Source / Build / Device / Real-world (doc section 16 ke hisaab se alag-alag)

Legend: ✅ = hua   🟡 = aanshik   ❌ = nahi hua   (Source = code likha, Build = Gradle compile, Device = real phone, Real-world = asli account/app)

**Abhi tak SAB ka Build, Device aur Real-world = ❌** (kuch bhi phone par chala nahi). "Logic-test" column = Android-independent hissa jo is session mein JVM par asli chalaya gaya.

| # | Feature | Source | Logic-test (JVM) | Build | Device | Real-world | Note |
|---|---------|:-----:|:-----:|:-----:|:-----:|:-----:|------|
| 1 | Task create/status/list/pause/resume/cancel/retry API | ✅ | ❌ | ❌ | ❌ | ❌ | atomic SQL transitions |
| 2 | Task persistence + checkpoint + boot/crash recovery | ✅ | ❌ | ❌ | ❌ | ❌ | Room DB v4 |
| 3 | Priority queue, 1 UI task at a time, deadline/timeout | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 4 | Selectors (id/desc/text/hierarchy/xy) + confidence + expiry | ✅ | ✅ 53 | ❌ | ❌ | ❌ | |
| 5 | Post-condition verify (no false success) | ✅ | ✅ (conditions) | ❌ | ❌ | ❌ | verifier polling device par hi chalega |
| 6 | Recovery ladder (scroll, alternate selector, escalate) | ✅ | ✅ (reasoner) | ❌ | ❌ | ❌ | rollback nahi |
| 7 | Mode A inline reply (notification) | ✅ | ✅ (store/compiler) | ❌ | ❌ | ❌ | delivery confirm nahi ho sakta |
| 8 | Mode B foreground UI + explicit allowForeground | ✅ | ✅ (compiler) | ❌ | ❌ | ❌ | |
| 9 | WhatsApp adapter | 🟡 starter | ✅ (expansion parses) | ❌ | ❌ | ❌ | selectors unverified |
| 10 | File transfer: chunk/pause/resume/SHA-256/atomic/policy | ✅ | ✅ 24 | ❌ | ❌ | ❌ | restart-resume tested on JVM |
| 11 | MCP tools (43 names incl. doc aliases) | ✅ | ✅ 193 (backend) | n/a | n/a | ❌ | relay allowlist cross-checked |
| 12 | Scoped tokens, rate limit, lockout, idempotency | ✅ | ✅ 31 | ❌ | ❌ | ❌ | LAN plain HTTP |
| 13 | Persistent Emergency Stop (local + remote) | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 14 | Foreground service specialUse, WakeLock, watchdog, battery UI | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 15 | Relay (reconnect/heartbeat) | ✅ (pehle se) | ✅ (backend) | ❌ | ❌ | ❌ | |
| 16 | long-click + key-press (back/home/recents/notifications/quick_settings/enter/clear) | ✅ | ✅ (parse/reasoner) | ❌ | ❌ | ❌ | enter = Android 11+ |
| 17 | Battery awareness (UI automation <=10% & not charging par ruk jaati hai) + /device/state | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 18 | File transfer: token-owner check, task label, file.progress events | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 19 | Limited rollback (unsent typed text mitana, sirf exact-match par) | ✅ | ❌ | ❌ | ❌ | ❌ | tap/send ka rollback nahi |
| 20 | Events: screen.changed, permission.changed, file.progress | ✅ | ❌ | ❌ | ❌ | ❌ | screen.changed sirf jab koi sun raha ho |
| 21 | Backend agent loop (agent_start/status/approve/stop) | ✅ | ✅ 80+ (scripted LLM + fake phone) | n/a | ❌ | ❌ | **asli Anthropic API call kabhi test nahi hui** (yahan network/key nahi); safety gates test hue |
| 22 | Live view (screenshot burst + optional browser page) | ✅ | ✅ (burst/cache) | ❌ | ❌ | ❌ | main.py viewer routes FastAPI ke bina test nahi hue |
| 23 | Local API default loopback-only + LAN switch | ✅ | ❌ | ❌ | ❌ | ❌ | |
| 24 | Task delete/purge, redactWhenDone, 7-din auto-delete | ✅ | ✅ (tools) | ❌ | ❌ | ❌ | Room queries device par hi chalenge |
| 25 | Open-app rollback (task ke baad pichli app/home par) | ✅ | ✅ 9 (RollbackPolicy) | ❌ | ❌ | ❌ | app-ke-andar ki state wapas nahi |
| 26 | Adapters: telegram, instagram, messenger, signal (+ whatsapp x2) | 🟡 starter | ✅ (expansion parses) | ❌ | ❌ | ❌ | selectors unverified |
| 27 | GitHub Actions: tests job (JVM + backend) | ✅ | ✅ (local run) | ❌ | n/a | n/a | |

## Jo ABHI BHI baaki / aanshik hai (saaf)
- 🟡 **Agent loop**: asli Anthropic API call test nahi hui; model ki quality/cost real use mein dekhni hogi; vision (screenshot bhejna) nahi — sirf element text/desc
- ❌ asli screen *video* stream (sirf screenshot burst; Android takeScreenshot ~0.3 s se tez nahi)
- 🟡 rollback: app-level wapasi + unsent typed text; bheje hue message/tap ka rollback possible nahi
- 🟡 `gradlew` wrapper nahi (zaroorat nahi — workflow Gradle 8.5 khud install karta hai)
- 🟡 repo structure `app/app/` — build green hone ke baad safe hoga
- 🟡 saare messaging adapters ("starter") ke selectors real phone par verify nahi hue
- ❌ Doc ke section 15 ke saare real-device tests (clean build, APK install, accessibility, process-kill, Doze, E2E ...)
- ❌ **Poora Android app ek baar bhi compile nahi hua** (GitHub Actions `build` job pehla compile karega)

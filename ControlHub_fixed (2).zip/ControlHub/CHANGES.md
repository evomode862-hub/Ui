# Changes

## Step 1 (build blockers + engine wiring)
- accessibility_service_config.xml: added canTakeScreenshot="true" (Android 11+ screenshot ke liye zaroori)
- AutomationReasoner: multi-command instructions (nayi line ya `;;`), sahi waqt par DONE (pehle kabhi DONE nahi aata tha)
- AutomationEngine: stepIndex tracking, cancel check har loop mein, cancelled task overwrite nahi hota, result audit log mein
- NEW TaskRunner: tasks background thread par, ek waqt mein ek UI task
- NEW API: POST /task/create (HIGH_RISK, confirm:true), GET /task/status?id=, GET /task/list, POST /task/cancel
- ApiScope + /capabilities manifest updated

Example: POST /task/create {"instructions":"open:com.android.settings;;scroll:down","confirm":true}
Note: Verify abhi bhi generic hai ("screen badli?") — Step 3 mein post-condition verify aayega.

## Step 2 (task system + persistence + recovery)
- TaskEntity: taskUuid, deviceId, priority, deadlineAt, currentStep (checkpoint), retryCount, recoveryCount, lastError; status ab paused bhi (DB version 3 — purana test data clear hoga)
- TaskDao: atomic status transitions (WHERE status guard) — API cancel/pause aur engine ek doosre ko overwrite nahi karte
- Engine: checkpoint har safal command ke baad, deadline check, pause/cancel ko respect karta hai
- TaskRunner: priority queue (bada priority pehle, phir FIFO), ek waqt mein ek UI task
- TaskRecovery: service start par stale 'running' -> pending (max 2 baar), pending tasks dobara queue mein, checkpoint se resume
- BootReceiver + RECEIVE_BOOT_COMPLETED: reboot / app-update ke baad service auto-start (Settings mein switch, default ON)
- DeviceIdentity: stable device_id
- API: /task/create (priority, timeoutSeconds), /task/status (id ya uuid), /task/list (status, limit), /task/pause, /task/resume, /task/retry, /task/cancel
- Emergency Stop ab paused tasks bhi cancel karta hai (single SQL)

## Step 3 (selectors + real verify + recovery)
- BUG FIX: readUi() pehle ek shared list clear+refill karta tha, isliye "before" aur "after" observation same object the aur Verify hamesha "screen unchanged" batata tha. Ab har call nayi list deta hai
- UiElement: contentDesc, packageName, depth, parentId (hierarchy), enabled, focused; /ui/read mein bhi
- NEW Selector: id= / desc= / text= / has= / cls= / within= / nth= / xy=, " & " se jodo, " || " se alternates. Priority: id -> desc -> text -> hierarchy -> coordinate. Har match par confidence; version/expiresAt metadata
- NEW PostCondition: " => appears:<sel> | gone:<sel> | pkg:<package> | text:<str> | none", kai conditions " && " se
- NEW AutomationCommand: parse + syntax error task banate waqt hi pakadta hai (HTTP 400)
- Verify: pehle explicit post-conditions, warna concrete default (open = app foreground, type = text dikhe, tap/back = screen badli, home/scroll lenient with note); UI settle hone tak poll
- Recovery ladder: element na mile -> scroll (max 2) -> alternate selector/candidate -> escalate; "task.needs_attention" event
- Click: pehle node ACTION_CLICK (clickable parent tak), phir coordinate fallback
- Audit: har step ka evidence (action, selector kind, confidence, result, note) — typed text/message content kabhi nahi

Example:
  open:com.whatsapp => pkg:com.whatsapp
  tap:desc=Search || id=menuitem_search
  tap:has=Ibrahim & within=Chats
  type:Hello
  tap:id=send || desc=Send || xy=980,2150 => gone:desc=Send

## Step 4 (notifications + WhatsApp adapter + Mode A/B)
- NEW NotificationListenerService (user ko Settings mein Notification access ON karna hoga): active notifications in-memory store (DB/audit mein kabhi nahi); events notification.posted / notification.removed
- Privacy: title/text API se tabhi dikhte hain jab Settings mein "Expose notification text via API" ON ho (default OFF)
- MODE A (background): inline reply (RemoteInput) — app ko screen par laye bina. API: POST /notification/reply (HIGH_RISK); task command reply:<pkg|*>|<contact|key>|<text>
- Reply ka delivery confirm nahi ho sakta: weak evidence (notification update/clear); verify fail par DUPLICATE ke darr se dobara nahi bhejta, seedha escalate
- MODE B (foreground): UI automation. Ab task create par explicit "allowForeground": true chahiye (nahi to 409 + needsForeground:true). Chalne se pehle screen on + unlocked check
- mode = auto | background | foreground. auto: adapter background support kare aur reply-able notification maujood ho to background, warna foreground
- NEW Adapters: GET /adapters; do:whatsapp.send_message|<contact>|<message> (aur whatsapp_business). Instructions task banate waqt expand hoti hain (DB mein expanded save, taaki resume checkpoint match kare)
- NEW commands: wait:<1-30 sec>, reply:..., do:...
- ADAPTER HONEST NOTE: WhatsApp ke Mode B selectors "starter" hain (known naming par based), real phone par verify nahi hue — pehle device test mein adjust honge
- GET /notifications, GET /adapters; Settings mein notification access button + status
- DB version 4 (tasks.mode)

Examples:
  {"instructions":"do:whatsapp.send_message|Ibrahim|Hello","mode":"auto","allowForeground":true,"confirm":true}
  {"instructions":"reply:com.whatsapp|Ibrahim|Hello","mode":"background","confirm":true}

## Step 5 (file transfer hardening + backend MCP tools)
Phone (Java):
- FilePolicy (NEW, pure Java): max 100 MB (413), blocked types apk/exe/sh/jar/... incl. double-extension "invoice.apk.pdf" (415); filename length/control-char checks
- TransferManager: SHA-256 — send status mein poori file ka sha256; receive par optional expected sha256, sab chunks ke baad match na ho to file DISCARD (state FAILED, HTTP 422); optional per-chunk sha256 (galat chunk reject, count nahi hota)
- Atomic finalize (temp .part -> received_files/ rename, global lock, same naam par " (1)"), max 8 active incoming (429), free-space check (507)
- Restart-resume: har incoming transfer ka .meta (received chunks) disk par; app restart ke baad same transferId se baaki chunks; status mein nextMissingIndex/missingCount; 24h purane adhure transfers saaf
- API: /file/receive/start {sha256?}, /file/receive/chunk {chunkSha256?}, /file/send/chunk response mein chunkSha256, sahi HTTP codes (413/415/422/429/507)
- NEW POST /emergency/stop (fail-safe, READ scope se bhi chalta hai) + GET /emergency/status. Resume sirf phone par (remote se nahi — jaanbujh kar)
Backend (Python):
- 13 naye MCP tools (ab 29): create_task, task_status, list_tasks, pause_task, resume_task, cancel_task, retry_task, stop_all_automation, get_notifications, reply_notification, list_adapters, send_file, receive_file
- file_tools.py: chunked + SHA-256 verified; send_file (phone->Claude, <=512 KB inline), receive_file (Claude->phone, <=1 MB, resume_transfer_id se resume)
- create_task / reply_notification confirm=true maangte hain; stop_all_automation ko confirm nahi chahiye (fail-safe)
Tests actually chalaye gaye (is session mein):
- TransferManager: 24/24 pass (real JVM) — roundtrip, sha mismatch, policy, traversal, chunk checksum, restart-resume, no-overwrite, pause/resume, cancel cleanup
- Automation logic (Selector/Command/PostCondition/Reasoner/InstructionCompiler/adapters, stub Android classes ke saath): 53/53 pass
- Backend: 122/122 checks pass (90 purane + 32 naye)

## Step 6 (security hardening + 24/7 reliability)
BUG FIX (important): RelayClient ka allowlist Step 1-5 ke endpoints (/task/*, /notifications, /notification/reply, /adapters, /emergency/*) ko block kar deta — yani naye MCP tools "Path not allowed by relay" dete. Ab allowlist mein hain. /auth/* jaanbujh kar NAHI (remote agent token nahi bana sakta). Script se check kiya: saare 31 MCP routes allowed.
Security:
- RateLimiter (300/min general, 20/min HIGH_RISK, file bucket 1200/min; emergency stop exempt) + brute-force lockout (8 galat token/60s -> IP 5 min lock)
- IdempotencyStore: HIGH_RISK POST ke liye idempotency key zaroori (428 agar nahi); replay par cached jawab, dobara execute nahi; optional X-Timestamp freshness
- Scoped tokens: POST /auth/tokens/create|revoke, GET /auth/tokens/list — master token + local only; hash-only storage; revoke turant
- Master token compare constant-time
- Emergency Stop flag disk par persist (reboot ke baad bhi ON); BootReceiver/service/API start par load
- allowBackup=false
Reliability:
- Foreground service type dataSync -> specialUse (Android 15 ke time limit se bachne ke liye)
- TaskRunner: PARTIAL_WAKE_LOCK sirf task chalte waqt (65 min hard timeout), engine crash par task failed mark
- TaskWatchdog (har 60s): stuck 'running' task re-queue/fail, expired pending task fail, kho gaya enqueue dobara, audit log latest 5000 rows
- Settings: battery optimization status + button (Doze se chhoot)
- Backend: create_task / reply_notification mein optional idempotency_key
- SECURITY.md: kya protect hota hai aur kya NAHI (honest)
Tests (is session mein actually chalaye): Security classes 31/31, TransferManager 24/24, automation logic 53/53 (stub Android ke saath), backend 124/124.

## Step 7 (baaki coding items)
- long-click + key-press: commands `longtap:<selectors>` aur `key:<back|home|recents|notifications|quick_settings|enter|clear>`; API POST /ui/long_click, POST /ui/key; MCP tools long_press, press_key
- Battery awareness: DeviceState.battery(); foreground (UI) automation <=10% aur charging nahi par ruk jaati hai (task failed + clear wajah)
- GET /device/state (battery, accessibility, notification access, screen lock, foreground app, active task, emergency stop, battery-optimization); MCP tool device_state
- File transfer: transfer shuru karne wale token ki ownership (scoped token doosre ki transferId nahi chhoo sakta; master sab), optional taskUuid label, "file.progress" events (har 10%)
- Limited rollback: task type: ke baad fail/cancel ho aur field mein abhi bhi wahi typed text ho (exact match) to mita deta hai
- Events: screen.changed (package+class, text nahi; sirf jab koi events sun raha ho), permission.changed (accessibility / notification_access), file.progress
- Tests: automation logic 66/66, backend 135/135; baaki suites pehle jaise

## Step 8 (baaki "ho sakta hai" items)
Phone:
- Local API + event server DEFAULT sirf loopback (127.0.0.1); Settings mein "Allow LAN access" switch (servers restart); serve() mein non-loopback reject
- Task delete/purge: POST /task/delete (WRITE), POST /task/purge (HIGH_RISK); `redactWhenDone` (task khatam hote hi message text mita do), 7-din auto-delete (Settings switch, default ON); DB v5
- Open-app rollback: task ke baad pichli app / home par wapas (`restoreApp`, default true); RollbackPolicy (pure, tested): Emergency Stop / locked screen / background task par kabhi nahi; **Emergency Stop ke baad typed-text rollback bhi UI nahi chalata (bug fix)**
- Relay: /screenshot?maxEdge=&quality= (live view ke chhote frames); Scene/ui-read mein contentDesc, package, enabled, focused
- Adapters: telegram, instagram, messenger, signal (MessagingAdapter) — "starter"
Backend:
- agent.py: agent_start / agent_status / agent_approve / agent_stop (screen -> Claude -> action loop) with backend-enforced safety (allowed_packages, approval gate, strict schema, limits, emergency/battery/lock checks); ANTHROPIC_API_KEY + AGENT_MODEL env
- liveview.py + MCP live_view (screenshot burst) + optional browser page /live/<MCP_SECRET> (LIVE_VIEW=1)
- MCP tools ab 43: + delete_task, purge_tasks, live_view, agent_*; create_task: restore_app, redact_when_done; array type validation
CI:
- .github/workflows/build-apk.yml: do jobs — `tests` (JVM + backend) aur `build` (APK), ek doosre par nirbhar; tests/jvm/ harness repo mein
Tests (is session mein asli chale): JVM — logic 101, security 31, file transfer 24; backend 193.

package com.controlhub.app.automation;

import java.util.ArrayList;
import java.util.List;

/**
 * Step 3 — Ek parsed command: action + (selectors) + (post-conditions).
 *
 *   open:<package> [=> conditions]
 *   tap:<selectors> [=> conditions]
 *   type:<text> [=> conditions]
 *   scroll:<up|down|left|right> [=> conditions]
 *   back [=> conditions]      home [=> conditions]
 */
public class AutomationCommand {

    public enum Action { OPEN, TAP, LONGTAP, TYPE, SCROLL, BACK, HOME, KEY, REPLY, WAIT }

    public final Action action;
    public final String arg;                     // package / text / direction
    public final List<Selector> selectors;       // TAP
    public final List<PostCondition> conditions; // khaali = default verify
    public String pkg;     // REPLY: notification ka app package ("*" = koi bhi)
    public String target;  // REPLY: contact/title ya notification key
    public int seconds;    // WAIT

    private AutomationCommand(Action action, String arg, List<Selector> selectors, List<PostCondition> conditions) {
        this.action = action;
        this.arg = arg;
        this.selectors = selectors;
        this.conditions = conditions;
    }

    /** UI (screen/accessibility) chalane wali command — Mode B (foreground) chahiye */
    public boolean isUi() {
        return action != Action.REPLY && action != Action.WAIT;
    }

    private static final java.util.Set<String> KEYS = new java.util.HashSet<>(java.util.Arrays.asList(
            "back", "home", "recents", "notifications", "quick_settings", "enter", "clear"));

    private static final String COND_SEP = " => ";

    /** @throws IllegalArgumentException galat syntax par (task banate waqt hi pakad liya jaata hai) */
    public static AutomationCommand parse(String raw) {
        String s = raw == null ? "" : raw.trim();
        if (s.isEmpty()) throw new IllegalArgumentException("Empty command");

        List<PostCondition> conditions = new ArrayList<>();
        int i = s.lastIndexOf(COND_SEP);
        if (i >= 0 && PostCondition.looksLikeCondition(s.substring(i + COND_SEP.length()))) {
            conditions = PostCondition.parseList(s.substring(i + COND_SEP.length()));
            s = s.substring(0, i).trim();
        }

        if (s.equals("back")) return new AutomationCommand(Action.BACK, null, null, conditions);
        if (s.equals("home")) return new AutomationCommand(Action.HOME, null, null, conditions);

        int colon = s.indexOf(':');
        if (colon < 0) throw new IllegalArgumentException("Unknown command: " + s);
        String name = s.substring(0, colon).trim();
        String arg = s.substring(colon + 1);

        switch (name) {
            case "open": {
                String pkg = arg.trim();
                if (pkg.isEmpty()) throw new IllegalArgumentException("open: needs a package name");
                return new AutomationCommand(Action.OPEN, pkg, null, conditions);
            }
            case "tap": {
                List<Selector> sel = Selector.parseAlternates(arg);
                return new AutomationCommand(Action.TAP, arg.trim(), sel, conditions);
            }
            case "longtap": { // Step 7: long-press (context menu waghera)
                List<Selector> sel = Selector.parseAlternates(arg);
                return new AutomationCommand(Action.LONGTAP, arg.trim(), sel, conditions);
            }
            case "key": { // Step 7
                String k = arg.trim().toLowerCase();
                if (!KEYS.contains(k)) {
                    throw new IllegalArgumentException("key: must be one of back, home, recents, notifications, quick_settings, enter, clear");
                }
                return new AutomationCommand(Action.KEY, k, null, conditions);
            }
            case "type": {
                if (arg.isEmpty()) throw new IllegalArgumentException("type: needs text");
                return new AutomationCommand(Action.TYPE, arg, null, conditions);
            }
            case "scroll": {
                String d = arg.trim().toLowerCase();
                if (!(d.equals("up") || d.equals("down") || d.equals("left") || d.equals("right"))) {
                    throw new IllegalArgumentException("scroll: direction must be up/down/left/right");
                }
                return new AutomationCommand(Action.SCROLL, d, null, conditions);
            }
            case "reply": {
                // reply:<package or *>|<contact or notification key>|<text>
                String[] parts = arg.split("\\|", 3);
                if (parts.length < 3 || parts[0].trim().isEmpty() || parts[1].trim().isEmpty() || parts[2].isEmpty()) {
                    throw new IllegalArgumentException("reply: format is reply:<package|*>|<contact|key>|<text>");
                }
                AutomationCommand c = new AutomationCommand(Action.REPLY, parts[2], null, conditions);
                c.pkg = parts[0].trim();
                c.target = parts[1].trim();
                return c;
            }
            case "wait": {
                int sec;
                try {
                    sec = Integer.parseInt(arg.trim());
                } catch (NumberFormatException e) {
                    throw new IllegalArgumentException("wait: needs seconds (1-30)");
                }
                if (sec < 1 || sec > 30) throw new IllegalArgumentException("wait: seconds must be 1-30");
                AutomationCommand c = new AutomationCommand(Action.WAIT, String.valueOf(sec), null, conditions);
                c.seconds = sec;
                return c;
            }
            default:
                throw new IllegalArgumentException("Unknown command: " + name);
        }
    }
}

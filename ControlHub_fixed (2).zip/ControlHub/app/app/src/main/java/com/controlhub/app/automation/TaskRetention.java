package com.controlhub.app.automation;

import android.content.Context;

/** Step 8 — khatam hue tasks ko 7 din baad auto-delete (default ON; Settings mein band ho sakta hai) */
public class TaskRetention {

    public static final long RETENTION_MS = 7L * 24 * 60 * 60 * 1000;
    private static final String PREFS = "control_hub_retention";
    private static final String KEY = "auto_delete";

    public static boolean isAutoDeleteEnabled(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, true);
    }

    public static void setAutoDeleteEnabled(Context c, boolean on) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, on).apply();
    }
}

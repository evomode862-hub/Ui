package com.controlhub.app.api;

import android.content.Context;

/**
 * Step 8 — Local API / event server kahan sunte hain.
 *  - DEFAULT: sirf loopback (127.0.0.1) — phone ke andar se hi (relay yahin se baat karta hai).
 *    Isse LAN par plain HTTP server khula nahi rehta.
 *  - Settings mein "Allow LAN access" ON karo to saare network interfaces par (PC se curl/test ke liye) —
 *    kam surakshit, sirf trusted WiFi par.
 */
public class NetworkBinding {

    private static final String PREFS = "control_hub_network";
    private static final String KEY_LAN = "allow_lan";

    public static boolean isLanAllowed(Context c) {
        return c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_LAN, false);
    }

    public static void setLanAllowed(Context c, boolean on) {
        c.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_LAN, on).apply();
    }

    /** NanoHTTPD hostname: loopback ya null (= sab interfaces) */
    public static String hostname(Context c) {
        return isLanAllowed(c) ? null : "127.0.0.1";
    }

    /** serve() mein defense-in-depth: local-only mode mein non-loopback client ko reject */
    public static boolean isLoopback(String ip) {
        return ip != null && (ip.equals("127.0.0.1") || ip.equals("::1") || ip.equals("0:0:0:0:0:0:0:1")
                || ip.startsWith("127.") || ip.equals("localhost"));
    }
}

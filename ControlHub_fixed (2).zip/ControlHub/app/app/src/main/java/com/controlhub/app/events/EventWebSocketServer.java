package com.controlhub.app.events;

import android.content.Context;
import android.util.Log;

import com.controlhub.app.api.ApiTokenManager;

import java.io.IOException;

import fi.iki.elonen.NanoWSD;

/**
 * Feature #50 — WebSocket/event stream setup
 *
 * Ye ek alag chhota server hai (port 8081) REST API (port 8080) se — taaki
 * ek hi socket pe do alag protocol mix na karne padein. Client connect karke
 * live events sunta rehta hai (Feature #51 ke events yahin se bahar jaate hain).
 *
 * Security: REST API ki tarah yahan bhi token chahiye — connect karte waqt
 * URL mein "?token=<X-Auth-Token wala token>" dena hoga, warna connection
 * turant reject ho jaata hai. (WebSocket handshake mein custom header
 * bhejna har client library mein easy nahi hota, isliye query param use kiya.)
 */
public class EventWebSocketServer extends NanoWSD {

    private static final String TAG = "EventWebSocketServer";
    public static final int PORT = 8081;

    private final Context context;

    public EventWebSocketServer(Context context) {
        super(com.controlhub.app.api.NetworkBinding.hostname(context), PORT); // Step 8: default sirf loopback
        this.context = context.getApplicationContext();
    }

    @Override
    protected WebSocket openWebSocket(IHTTPSession handshake) {
        // Token check — query param se
        java.util.List<String> tokenParam = handshake.getParameters().get("token");
        String token = (tokenParam != null && !tokenParam.isEmpty()) ? tokenParam.get(0) : null;

        boolean authorized = ApiTokenManager.isValid(context, token);
        return new EventClientSocket(handshake, authorized);
    }

    private class EventClientSocket extends WebSocket implements EventBus.EventSink {

        private final boolean authorized;

        EventClientSocket(IHTTPSession handshake, boolean authorized) {
            super(handshake);
            this.authorized = authorized;
        }

        @Override
        protected void onOpen() {
            if (!authorized) {
                try {
                    close(WebSocketFrame.CloseCode.PolicyViolation, "Invalid or missing token", false);
                } catch (IOException e) {
                    Log.w(TAG, "Error closing unauthorized socket", e);
                }
                return;
            }
            EventBus.register(this);
        }

        @Override
        protected void onClose(WebSocketFrame.CloseCode code, String reason, boolean initiatedByRemote) {
            EventBus.unregister(this);
        }

        @Override
        protected void onMessage(WebSocketFrame message) {
            // Ye stream sirf server -> client events ke liye hai. Client se aane
            // wale messages ko abhi ignore karte hain (commands REST API se jaate hain)
        }

        @Override
        protected void onPong(WebSocketFrame pong) {
        }

        @Override
        protected void onException(IOException exception) {
            Log.w(TAG, "WebSocket exception: " + exception.getMessage());
            EventBus.unregister(this);
        }

        // EventBus.EventSink implementation
        @Override
        public void send(String json) {
            try {
                super.send(json);
            } catch (IOException e) {
                throw new RuntimeException(e); // EventBus.publish() ise pakad ke is client ko hata dega
            }
        }
    }
}

package com.controlhub.app.security;

import android.content.Context;

import com.controlhub.app.data.AppDatabase;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Feature #43 — Emergency Stop
 *
 * Trigger hone par: saare active automation tasks turant "cancelled" mark
 * ho jaate hain, aur naye actions Task Queue (Stage 5) mein reject ho jaate
 * hain jab tak koi Resume na kare.
 *
 * IMPORTANT (roadmap ka apna rule): Emergency Stop sirf automation rokta
 * hai — app ka data (settings, saved apps list, logs) delete NAHI karta.
 * Ye jaanbujh ke aisa hai, taaki galti se panic mein data na kho jaye.
 */
public class EmergencyStopManager {

    private static final String PREFS = "control_hub_emergency";
    private static final String KEY = "stopped";

    private static volatile boolean stopped = false;
    private static final ExecutorService executor = Executors.newSingleThreadExecutor();

    /**
     * Step 6: flag ab disk par save hota hai — app restart / phone reboot ke baad bhi Emergency Stop
     * ON rehta hai (pehle memory mein tha, process mar jaane par chupchaap OFF ho jata tha).
     * Service/Boot/API start par ek baar call karo.
     */
    public static void init(Context context) {
        stopped = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, false);
    }

    private static void persist(Context context, boolean value) {
        // commit() (apply nahi) — process turant mare to bhi flag disk par pahunch chuka ho
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY, value).commit();
    }

    public static boolean isStopped() {
        return stopped;
    }

    /** Feature #43 — turant sab rok do */
    public static void trigger(Context context) {
        stopped = true;
        persist(context, true);

        executor.execute(() -> {
            AppDatabase db = AppDatabase.getInstance(context.getApplicationContext());
            db.taskDao().cancelAllActive(System.currentTimeMillis()); // pending + running + paused
        });

        AuditLogger.warning(context, "EMERGENCY STOP triggered — all automation halted");
    }

    /** Emergency stop hatane ke liye — data touch nahi karta, sirf flag reset karta hai */
    public static void resume(Context context) {
        stopped = false;
        persist(context, false);
        AuditLogger.info(context, "Emergency stop cleared — automation can resume");
    }
}

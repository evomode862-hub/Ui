package com.controlhub.app;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.controlhub.app.accessibility.AccessibilityPermissionHelper;
import com.controlhub.app.api.LocalApiServer;
import com.controlhub.app.apps.AppListAdapter;
import com.controlhub.app.apps.InstalledAppsManager;
import com.controlhub.app.data.AppEntity;
import com.controlhub.app.integration.NexIntegrationTester;
import com.controlhub.app.security.EmergencyStopManager;
import com.controlhub.app.service.ControlHubForegroundService;

import java.util.List;
import java.util.concurrent.Executors;

/**
 * Feature #1 — Foundation (project structure)
 * Feature #2 — Dashboard UI (ye hi Dashboard screen hai)
 * Feature #6/#7 — Installed apps nikaal ke RecyclerView mein dikhana
 * Feature #11 — Accessibility ON karne ka button
 * Feature #27/#28 — API Server ab Foreground Service ke through chalta hai,
 *                    isliye app minimize/close hone ke baad bhi zinda rehta hai
 */
public class MainActivity extends AppCompatActivity {

    private static final int NOTIFICATION_PERMISSION_REQUEST = 501;

    private Button serverToggleButton;
    private TextView serverStatusText;
    private Button emergencyStopButton;
    private TextView emergencyStatusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Feature #27 — Android 13+ par persistent notification dikhane ke liye
        // runtime permission chahiye, warna service to chalegi lekin notification
        // silently nahi dikhega
        requestNotificationPermissionIfNeeded();

        Button enableAccessibilityButton = findViewById(R.id.enableAccessibilityButton);
        enableAccessibilityButton.setOnClickListener(v ->
                AccessibilityPermissionHelper.openAccessibilitySettings(this));

        // Settings screen (API token, scopes, relay) — pehle Dashboard se khulta hi nahi tha
        findViewById(R.id.settingsButton).setOnClickListener(v ->
                startActivity(new Intent(this, SettingsActivity.class)));

        serverToggleButton = findViewById(R.id.serverToggleButton);
        serverStatusText = findViewById(R.id.serverStatusText);

        updateServerStatusUi();

        serverToggleButton.setOnClickListener(v -> {
            if (ControlHubForegroundService.isRunning()) {
                ControlHubForegroundService.stop(this);
            } else {
                ControlHubForegroundService.start(this);
            }
            // Feature #28 — service start/stop async hai, thodi der baad status refresh karo
            serverToggleButton.postDelayed(this::updateServerStatusUi, 500);
        });

        RecyclerView recyclerView = findViewById(R.id.appListRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Feature #43 — Emergency Stop
        emergencyStopButton = findViewById(R.id.emergencyStopButton);
        emergencyStatusText = findViewById(R.id.emergencyStatusText);
        updateEmergencyStatusUi();

        emergencyStopButton.setOnClickListener(v -> {
            if (EmergencyStopManager.isStopped()) {
                EmergencyStopManager.resume(this);
            } else {
                EmergencyStopManager.trigger(this);
            }
            updateEmergencyStatusUi();
        });

        // Feature #53 — Nex integration self-test (network call hai, background thread pe)
        Button nexTestButton = findViewById(R.id.nexTestButton);
        TextView nexTestResultText = findViewById(R.id.nexTestResultText);
        nexTestButton.setOnClickListener(v -> {
            nexTestResultText.setText("Testing...");
            Executors.newSingleThreadExecutor().execute(() -> {
                NexIntegrationTester.TestResult result = NexIntegrationTester.run(this);
                runOnUiThread(() -> nexTestResultText.setText(result.report));
            });
        });

        // Feature #6 — apps ki list background thread pe nikaalo (PackageManager query
        // bhaari ho sakti hai, main thread pe nahi karni chahiye)
        Executors.newSingleThreadExecutor().execute(() -> {
            List<AppEntity> apps = InstalledAppsManager.queryInstalledApps(this);
            InstalledAppsManager.syncToDatabase(this);

            runOnUiThread(() -> {
                AppListAdapter adapter = new AppListAdapter(this, apps);
                recyclerView.setAdapter(adapter);
            });
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Dashboard pe wapas aane par (jaise Settings se) status sahi dikhana chahiye
        updateServerStatusUi();
        updateEmergencyStatusUi();
    }

    private void updateEmergencyStatusUi() {
        if (EmergencyStopManager.isStopped()) {
            emergencyStatusText.setText("EMERGENCY STOP ACTIVE — automation halted");
            emergencyStopButton.setText("Resume");
        } else {
            emergencyStatusText.setText("");
            emergencyStopButton.setText("Emergency Stop");
        }
    }

    private void updateServerStatusUi() {
        if (ControlHubForegroundService.isRunning()) {
            serverStatusText.setText("Server running on port " + LocalApiServer.PORT + " (background)");
            serverToggleButton.setText("Stop API Server");
        } else {
            serverStatusText.setText("Server stopped");
            serverToggleButton.setText("Start API Server");
        }
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        NOTIFICATION_PERMISSION_REQUEST);
            }
        }
    }

    // Note: onDestroy() mein ab jaanbujh ke server stop NAHI karte —
    // Feature #27 ka poora point hi ye hai ki Activity band hone ke baad
    // bhi Foreground Service (aur uske andar ka server) chalta rahe.
}

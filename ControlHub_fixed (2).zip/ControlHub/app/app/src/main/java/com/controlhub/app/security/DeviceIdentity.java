package com.controlhub.app.security;

import android.content.Context;

import java.util.UUID;

/** Step 2 — is phone ka stable device_id (pehli baar random UUID banta hai, phir hamesha wahi). */
public class DeviceIdentity {

    private static final String PREFS = "control_hub_identity";
    private static final String KEY = "device_id";

    public static synchronized String get(Context context) {
        android.content.SharedPreferences p = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String id = p.getString(KEY, null);
        if (id == null) {
            id = "dev-" + UUID.randomUUID().toString().substring(0, 8);
            p.edit().putString(KEY, id).apply();
        }
        return id;
    }
}

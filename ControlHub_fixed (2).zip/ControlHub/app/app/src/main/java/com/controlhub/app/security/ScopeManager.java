package com.controlhub.app.security;

import android.content.Context;
import android.content.SharedPreferences;

/**
 * Feature #39 — Scope system (on/off switches)
 *
 * Har scope default ON hai (app kaam kar sake), lekin user Settings se
 * kisi bhi scope ko OFF kar sakta hai — jaise agar WRITE/HIGH_RISK
 * actions abhi nahi chahiye, sirf monitoring (READ) chahiye.
 *
 * Note: ye token ki jagah nahi leta — token valid hona alag cheez hai
 * (Feature #20), scope enabled hona alag (ye file). Dono sahi hone chahiye.
 */
public class ScopeManager {

    private static final String PREFS_NAME = "control_hub_scope_prefs";

    public static boolean isEnabled(Context context, ApiScope scope) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(keyFor(scope), true); // default: sab scopes ON
    }

    public static void setEnabled(Context context, ApiScope scope, boolean enabled) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putBoolean(keyFor(scope), enabled)
                .apply();
    }

    private static String keyFor(ApiScope scope) {
        return "scope_" + scope.name();
    }
}

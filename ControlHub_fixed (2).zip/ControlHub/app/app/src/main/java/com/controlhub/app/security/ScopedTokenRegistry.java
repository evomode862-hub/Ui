package com.controlhub.app.security;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;

/**
 * Step 6 — Scoped tokens (PURE JAVA, test-able). Master token ke alawa naam wale tokens, har ek
 * sirf kuch scopes ke saath (jaise sirf READ wala dashboard token). Plain token sirf banate waqt ek
 * baar dikhta hai — yahan sirf SHA-256 hash save hota hai. Revoke turant kaam karta hai.
 */
public class ScopedTokenRegistry {

    public static final int READ = 1, WRITE = 2, HIGH_RISK = 4;
    private static final int MAX_ACTIVE = 20;

    public interface Store {
        String load();
        void save(String data);
    }

    public static class Entry {
        public final String id;
        public final String name;
        final String hash;
        public final int mask;
        public final long createdAt;
        public boolean revoked;

        Entry(String id, String name, String hash, int mask, long createdAt, boolean revoked) {
            this.id = id;
            this.name = name;
            this.hash = hash;
            this.mask = mask;
            this.createdAt = createdAt;
            this.revoked = revoked;
        }
    }

    public static class Created {
        public final Entry entry;
        public final String plainToken; // sirf ek baar
        Created(Entry entry, String plainToken) {
            this.entry = entry;
            this.plainToken = plainToken;
        }
    }

    private final Store store;
    private final SecureRandom random = new SecureRandom();
    private final List<Entry> entries = new ArrayList<>();

    public ScopedTokenRegistry(Store store) {
        this.store = store;
        load();
    }

    private static String sha256Hex(String s) {
        try {
            byte[] h = MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : h) sb.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalStateException(e);
        }
    }

    private static String cleanName(String name) {
        String n = name == null ? "" : name.replaceAll("[\\t\\r\\n]", " ").trim();
        if (n.isEmpty()) throw new IllegalArgumentException("name is required");
        return n.length() > 40 ? n.substring(0, 40) : n;
    }

    public synchronized Created create(String name, int mask) {
        if (mask <= 0 || mask > 7) throw new IllegalArgumentException("scopes must include at least one of READ, WRITE, HIGH_RISK");
        int active = 0;
        for (Entry e : entries) if (!e.revoked) active++;
        if (active >= MAX_ACTIVE) throw new IllegalStateException("Too many active tokens (max " + MAX_ACTIVE + ") — revoke some first");

        byte[] raw = new byte[24];
        random.nextBytes(raw);
        StringBuilder hex = new StringBuilder();
        for (byte b : raw) hex.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));
        String plain = "ch_" + hex; // java.util.Base64 minSdk 24 par nahi — isliye hex
        byte[] idRaw = new byte[4];
        random.nextBytes(idRaw);
        StringBuilder id = new StringBuilder();
        for (byte b : idRaw) id.append(Character.forDigit((b >> 4) & 0xF, 16)).append(Character.forDigit(b & 0xF, 16));

        Entry e = new Entry(id.toString(), cleanName(name), sha256Hex(plain), mask, System.currentTimeMillis(), false);
        entries.add(e);
        persist();
        return new Created(e, plain);
    }

    /** Valid, revoke-na-hua token ho to uska Entry, warna null (constant-time hash compare) */
    public synchronized Entry authenticate(String token) {
        if (token == null || !token.startsWith("ch_")) return null;
        byte[] given = sha256Hex(token).getBytes(StandardCharsets.UTF_8);
        Entry found = null;
        for (Entry e : entries) {
            boolean same = MessageDigest.isEqual(given, e.hash.getBytes(StandardCharsets.UTF_8));
            if (same && !e.revoked) found = e;
        }
        return found;
    }

    public synchronized boolean revoke(String id) {
        for (Entry e : entries) {
            if (e.id.equals(id) && !e.revoked) {
                e.revoked = true;
                persist();
                return true;
            }
        }
        return false;
    }

    public synchronized List<Entry> list() {
        return new ArrayList<>(entries);
    }

    private void persist() {
        StringBuilder sb = new StringBuilder();
        for (Entry e : entries) {
            sb.append(e.id).append('\t').append(e.name).append('\t').append(e.hash).append('\t')
                    .append(e.mask).append('\t').append(e.createdAt).append('\t').append(e.revoked ? 1 : 0).append('\n');
        }
        store.save(sb.toString());
    }

    private void load() {
        String data = store.load();
        if (data == null || data.isEmpty()) return;
        for (String line : data.split("\n")) {
            String[] p = line.split("\t");
            if (p.length != 6) continue;
            try {
                entries.add(new Entry(p[0], p[1], p[2], Integer.parseInt(p[3]), Long.parseLong(p[4]), "1".equals(p[5])));
            } catch (NumberFormatException ignored) {
            }
        }
    }
}

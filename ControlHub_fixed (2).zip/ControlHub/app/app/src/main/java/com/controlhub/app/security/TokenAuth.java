package com.controlhub.app.security;

import android.content.Context;
import android.content.SharedPreferences;

import com.controlhub.app.api.ApiTokenManager;

/**
 * Step 6 — Kaun call kar raha hai: master token ya naam wala scoped token (sirf kuch scopes ke saath).
 * Master token ke upar bhi Settings ke global scope switches lagte rehte hain.
 */
public class TokenAuth {

    public static class Principal {
        public final boolean master;
        public final String id;
        public final String name;
        final int mask;

        Principal(boolean master, String id, String name, int mask) {
            this.master = master;
            this.id = id;
            this.name = name;
            this.mask = mask;
        }

        public boolean allows(ApiScope scope) {
            if (master) return true;
            switch (scope) {
                case READ: return (mask & ScopedTokenRegistry.READ) != 0;
                case WRITE: return (mask & ScopedTokenRegistry.WRITE) != 0;
                default: return (mask & ScopedTokenRegistry.HIGH_RISK) != 0;
            }
        }

        public String label() {
            return master ? "master" : "token:" + name;
        }
    }

    private static ScopedTokenRegistry registry;

    public static synchronized ScopedTokenRegistry registry(Context context) {
        if (registry == null) {
            final Context app = context.getApplicationContext();
            registry = new ScopedTokenRegistry(new ScopedTokenRegistry.Store() {
                @Override
                public String load() {
                    return ApiTokenManager.securePrefs(app).getString("scoped_tokens", "");
                }

                @Override
                public void save(String data) {
                    SharedPreferences.Editor e = ApiTokenManager.securePrefs(app).edit();
                    e.putString("scoped_tokens", data).apply();
                }
            });
        }
        return registry;
    }

    /** null = token galat/revoked */
    public static Principal authenticate(Context context, String token) {
        if (token == null || token.isEmpty()) return null;
        if (ApiTokenManager.isValid(context, token)) {
            return new Principal(true, "master", "master", 7);
        }
        ScopedTokenRegistry.Entry e = registry(context).authenticate(token);
        if (e == null) return null;
        return new Principal(false, e.id, e.name, e.mask);
    }

    public static int maskFromNames(java.util.List<String> names) {
        int mask = 0;
        for (String n : names) {
            switch (n.trim().toUpperCase()) {
                case "READ": mask |= ScopedTokenRegistry.READ; break;
                case "WRITE": mask |= ScopedTokenRegistry.WRITE; break;
                case "HIGH_RISK": mask |= ScopedTokenRegistry.HIGH_RISK; break;
                default: throw new IllegalArgumentException("Unknown scope: " + n);
            }
        }
        return mask;
    }
}

package com.controlhub.app.automation;

import android.content.Context;
import android.util.Log;

import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.TaskDao;
import com.controlhub.app.data.TaskEntity;
import com.controlhub.app.security.AuditLogger;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Step 2 — Crash / restart recovery.
 *
 * Process start par (service start ya phone reboot ke baad) DB dekhta hai:
 *  - 'running' tasks stale hain (process mar gaya tha) -> 'pending' (recoveryCount+1), max MAX_RECOVERIES baar
 *  - saare 'pending' tasks dobara queue mein (currentStep checkpoint se resume)
 *  - 'paused' tasks paused hi rehte hain (user ne roka tha)
 * Ek process mein sirf ek baar chalta hai (service ke baar-baar start hone par live task ko na chhede).
 */
public class TaskRecovery {

    private static final String TAG = "TaskRecovery";
    private static final int MAX_RECOVERIES = 2;
    private static final AtomicBoolean DONE = new AtomicBoolean(false);

    public static void recoverOnce(Context context) {
        if (!DONE.compareAndSet(false, true)) return;
        final Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                TaskDao dao = AppDatabase.getInstance(app).taskDao();
                long now = System.currentTimeMillis();

                int recovered = 0, gaveUp = 0;
                for (TaskEntity t : dao.getByStatus("running")) {
                    if (t.recoveryCount >= MAX_RECOVERIES) {
                        dao.markFailed(t.id, now, "Interrupted " + (t.recoveryCount + 1) + " times (process kill) — giving up");
                        AuditLogger.error(app, "Task " + t.id + " failed — too many interruptions");
                        gaveUp++;
                    } else if (dao.markInterrupted(t.id, now) > 0) {
                        recovered++;
                    }
                }

                List<TaskEntity> pending = dao.getByStatus("pending");
                for (TaskEntity t : pending) {
                    TaskRunner.enqueue(app, t.id, t.priority);
                }
                if (recovered > 0 || gaveUp > 0 || !pending.isEmpty()) {
                    AuditLogger.warning(app, "Task recovery: " + recovered + " interrupted resumed, "
                            + gaveUp + " given up, " + pending.size() + " queued");
                }
                Log.i(TAG, "recovered=" + recovered + " gaveUp=" + gaveUp + " queued=" + pending.size());
            } catch (Throwable e) {
                Log.e(TAG, "Recovery failed", e);
            }
        }, "task-recovery").start();
    }
}

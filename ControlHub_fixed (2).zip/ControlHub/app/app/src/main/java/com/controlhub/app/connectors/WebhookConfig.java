package com.controlhub.app.connectors;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;

/**
 * Feature #58 — Webhook connector ki settings.
 * Webhook URL ke path mein aksar secret hota hai (bot token wagairah), isliye
 * encrypted storage mein — aur agar wo na bane to plaintext par NAHI girte (RelayConfig jaisa).
 */
public class WebhookConfig {

    private static final String TAG = "WebhookConfig";
    private static final String PREFS_NAME = "control_hub_webhook_prefs_encrypted";
    private static final String KEY_URL = "webhook_url";
    private static final String KEY_ALL = "forward_all";

    private static SharedPreferences prefs(Context context) {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();
            return EncryptedSharedPreferences.create(
                    context, PREFS_NAME, masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);
        } catch (Exception e) {
            Log.e(TAG, "Encrypted storage unavailable — webhook config disabled", e);
            return null;
        }
    }

    public static String getUrl(Context context) {
        SharedPreferences p = prefs(context);
        return p == null ? "" : p.getString(KEY_URL, "");
    }

    public static boolean isForwardAll(Context context) {
        SharedPreferences p = prefs(context);
        return p != null && p.getBoolean(KEY_ALL, false);
    }

    public static boolean isConfigured(Context context) {
        return !getUrl(context).isEmpty();
    }

    /** @return null agar save ho gaya, warna error message. Blank URL = webhook band. */
    public static String save(Context context, String rawUrl, boolean forwardAll) {
        SharedPreferences p = prefs(context);
        if (p == null) {
            return "Encrypted storage is not available on this device";
        }
        String url = rawUrl == null ? "" : rawUrl.trim();
        if (url.isEmpty()) {
            p.edit().remove(KEY_URL).putBoolean(KEY_ALL, forwardAll).apply();
            return null;
        }
        String problem = WebhookPolicy.validateUrl(url);
        if (problem != null) {
            return problem;
        }
        p.edit().putString(KEY_URL, url).putBoolean(KEY_ALL, forwardAll).apply();
        return null;
    }
}

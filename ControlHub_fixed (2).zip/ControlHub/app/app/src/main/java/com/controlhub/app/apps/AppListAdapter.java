package com.controlhub.app.apps;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.controlhub.app.R;
import com.controlhub.app.data.AppEntity;

import java.util.List;

/**
 * Feature #7 — Dashboard pe installed apps dikhana (RecyclerView adapter)
 * Feature #8 — row par tap = launch
 * Feature #9 — "Stop" button = stopApp() best-effort
 * Feature #10 — status text (Running / Not running / Unknown)
 */
public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.AppViewHolder> {

    private final List<AppEntity> apps;
    private final Context context;

    public AppListAdapter(Context context, List<AppEntity> apps) {
        this.context = context;
        this.apps = apps;
    }

    @NonNull
    @Override
    public AppViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false);
        return new AppViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AppViewHolder holder, int position) {
        AppEntity app = apps.get(position);

        holder.label.setText(app.appLabel);
        holder.packageName.setText(app.packageName);

        try {
            Drawable icon = context.getPackageManager().getApplicationIcon(app.packageName);
            holder.icon.setImageDrawable(icon);
        } catch (Exception e) {
            holder.icon.setImageDrawable(null);
        }

        if (!InstalledAppsManager.hasUsageAccessPermission(context)) {
            holder.status.setText("Status: unknown (Usage Access off)");
        } else if (app.isRunning) {
            holder.status.setText("Running");
        } else {
            holder.status.setText("Not running");
        }

        // Feature #8 — row tap = launch app
        holder.itemView.setOnClickListener(v ->
                InstalledAppsManager.launchApp(context, app.packageName));

        // Feature #9 — Stop button = best-effort stop
        holder.stopButton.setOnClickListener(v ->
                InstalledAppsManager.stopApp(context, app.packageName));
    }

    @Override
    public int getItemCount() {
        return apps.size();
    }

    static class AppViewHolder extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView label;
        TextView packageName;
        TextView status;
        Button stopButton;

        AppViewHolder(@NonNull View itemView) {
            super(itemView);
            icon = itemView.findViewById(R.id.appIcon);
            label = itemView.findViewById(R.id.appLabel);
            packageName = itemView.findViewById(R.id.appPackage);
            status = itemView.findViewById(R.id.appStatus);
            stopButton = itemView.findViewById(R.id.stopButton);
        }
    }
}

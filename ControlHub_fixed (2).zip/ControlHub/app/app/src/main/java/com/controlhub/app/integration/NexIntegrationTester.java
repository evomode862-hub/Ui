package com.controlhub.app.integration;

import android.content.Context;

import com.controlhub.app.api.ApiTokenManager;
import com.controlhub.app.api.LocalApiServer;
import com.controlhub.app.events.EventWebSocketServer;
import com.controlhub.app.security.AuditLogger;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.URL;

/**
 * Feature #53 — Nex Browser / Master Agent ke saath test connection
 *
 * IMPORTANT (honest scope note): Nex Browser ka apna code is project mein
 * nahi hai, isliye yahan se seedha "Nex Browser se connect hoke dekhna"
 * possible nahi. Ye class wahi kaam karti hai jo Nex Browser (ya koi bhi
 * Master Agent) karega — apne hi server ko loopback (127.0.0.1) pe call
 * karke check karti hai ki Control Hub ki taraf se sab kuch integration
 * ke liye taiyar hai:
 *   1. /health jawab deta hai
 *   2. token ke saath /capabilities sahi manifest deta hai
 *   3. event stream (WebSocket) ka port sun raha hai
 * Agar ye teeno pass ho jaayein, to Nex Browser ke taraf se bas wahi HTTP
 * calls likhni hongi — Control Hub ko aur kuch badalna nahi padega.
 *
 * Network kaam hai — background thread se call karna zaroori hai.
 */
public class NexIntegrationTester {

    public static class TestResult {
        public final boolean allPassed;
        public final String report;

        TestResult(boolean allPassed, String report) {
            this.allPassed = allPassed;
            this.report = report;
        }
    }

    public static TestResult run(Context context) {
        StringBuilder report = new StringBuilder();
        boolean allPassed = true;

        // Check 1 — /health (bina token ke)
        try {
            String body = httpGet("http://127.0.0.1:" + LocalApiServer.PORT + "/health", null);
            boolean ok = new JSONObject(body).optString("status").equals("running");
            report.append(ok ? "PASS" : "FAIL").append(" — /health\n");
            allPassed &= ok;
        } catch (Exception e) {
            report.append("FAIL — /health (").append(e.getMessage()).append(")\n");
            allPassed = false;
        }

        // Check 2 — /capabilities (token ke saath)
        try {
            String token = ApiTokenManager.getOrCreateToken(context);
            String body = httpGet("http://127.0.0.1:" + LocalApiServer.PORT + "/capabilities", token);
            JSONObject manifest = new JSONObject(body);
            boolean ok = "android_control_hub".equals(manifest.optString("domain"))
                    && manifest.optJSONArray("endpoints") != null
                    && manifest.optJSONArray("endpoints").length() > 0;
            report.append(ok ? "PASS" : "FAIL").append(" — /capabilities manifest (")
                    .append(manifest.optJSONArray("endpoints") != null
                            ? manifest.optJSONArray("endpoints").length() : 0)
                    .append(" endpoints)\n");
            allPassed &= ok;
        } catch (Exception e) {
            report.append("FAIL — /capabilities (").append(e.getMessage()).append(")\n");
            allPassed = false;
        }

        // Check 3 — event stream port sun raha hai?
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress("127.0.0.1", EventWebSocketServer.PORT), 1500);
            report.append("PASS — event stream port ").append(EventWebSocketServer.PORT).append(" reachable\n");
        } catch (Exception e) {
            report.append("FAIL — event stream port ").append(EventWebSocketServer.PORT)
                    .append(" (").append(e.getMessage()).append(")\n");
            allPassed = false;
        }

        if (!allPassed) {
            report.append("\nHint: pehle 'Start API Server' dabao, phir test chalao.");
        }

        AuditLogger.info(context, "Nex integration self-test: " + (allPassed ? "PASSED" : "FAILED"));
        return new TestResult(allPassed, report.toString());
    }

    private static String httpGet(String urlString, String token) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(urlString).openConnection();
        conn.setConnectTimeout(2000);
        conn.setReadTimeout(3000);
        conn.setRequestMethod("GET");
        if (token != null) {
            conn.setRequestProperty("X-Auth-Token", token);
        }

        int code = conn.getResponseCode();
        if (code != 200) {
            throw new Exception("HTTP " + code);
        }

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            return sb.toString();
        } finally {
            conn.disconnect();
        }
    }
}

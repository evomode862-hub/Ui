package com.controlhub.app.apkhost;

import android.content.Context;
import android.content.pm.PackageManager;
import android.os.Build;

import com.controlhub.app.apps.InstalledAppsManager;

/**
 * Feature #48 — Runtime compatibility check
 * Feature #49 — Unsupported case mein clear error + external-launch fallback
 *
 * IMPORTANT (honest technical boundary — roadmap ka apna rule bhi yahi kehta
 * hai): Android par kisi bhi third-party APK ko "embedded" tarike se apne
 * process ke andar container/webpage ki tarah chalana normal, safe Android
 * APIs se possible NAHI hai. Real virtualization/container runtime (jaise
 * VirtualApp-style hacks) unofficial, fragile-across-Android-versions, aur
 * bahut risky (sandboxing bypass) hain — is app mein wo tareeka jaanbujh ke
 * nahi liya gaya.
 *
 * Isliye ye adapter kabhi "trulyEmbedded = true" nahi bolta — ye sirf
 * pata karta hai ki APK already installed hai ya nahi, aur agar hai to
 * normal Android launch (external, apni tarah ki alag app process) karta
 * hai. Agar installed nahi hai, to clearly bata deta hai ki pehle install
 * karna padega — koi silent/fake success nahi.
 */
public class ExternalLaunchRuntimeAdapter implements RuntimeAdapter {

    @Override
    public boolean isSupported(Context context, HostedApkEntity apk) {
        return isAlreadyInstalled(context, apk.packageName);
    }

    @Override
    public LaunchResult launch(Context context, HostedApkEntity apk) {
        // Feature #48 — pehle compatibility check
        if (!isAlreadyInstalled(context, apk.packageName)) {
            // Feature #49 — clear, honest error — koi fake "launched" nahi
            return new LaunchResult(false, false,
                    "Not installed on this device. Android security rules don't allow " +
                            "silently installing an APK from another app — the user must " +
                            "install it first (via the system installer), then it can be launched.");
        }

        boolean launched = InstalledAppsManager.launchApp(context, apk.packageName);
        if (launched) {
            return new LaunchResult(true, false,
                    "Launched as a normal external app process (not embedded — see class-level note)");
        }
        return new LaunchResult(false, false, "Installed, but launch failed (no launchable activity found)");
    }

    private boolean isAlreadyInstalled(Context context, String packageName) {
        try {
            context.getPackageManager().getPackageInfo(packageName, 0);
            return true;
        } catch (PackageManager.NameNotFoundException e) {
            return false;
        }
    }

    /** Feature #48 helper — device ki Android version bhi ek compatibility factor hai */
    public static boolean isDeviceSdkSupported(int apkMinSdk) {
        return Build.VERSION.SDK_INT >= apkMinSdk;
    }
}

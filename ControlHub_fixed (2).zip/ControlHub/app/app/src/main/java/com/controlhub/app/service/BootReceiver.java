package com.controlhub.app.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import com.controlhub.app.security.AuditLogger;

/**
 * Step 2 — Phone reboot (ya app update) ke baad Control Hub service khud chalu.
 * Setting: "Start on boot" (Settings screen mein switch, default ON).
 */
public class BootReceiver extends BroadcastReceiver {

    private static final String PREFS = "control_hub_boot_prefs";
    private static final String KEY = "start_on_boot";

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY, true);
    }

    public static void setEnabled(Context context, boolean enabled) {
        SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putBoolean(KEY, enabled).apply();
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent == null ? null : intent.getAction();
        if (!Intent.ACTION_BOOT_COMPLETED.equals(action)
                && !Intent.ACTION_MY_PACKAGE_REPLACED.equals(action)) {
            return;
        }
        com.controlhub.app.security.EmergencyStopManager.init(context); // reboot ke baad bhi stop yaad rahe
        if (!isEnabled(context)) {
            Log.i("BootReceiver", "Start-on-boot is OFF — not starting service");
            return;
        }
        try {
            ControlHubForegroundService.start(context);
            AuditLogger.info(context, "Service started by " + action);
        } catch (Exception e) {
            // Android background-start restrictions: crash nahi, bas log
            Log.e("BootReceiver", "Could not start service from " + action, e);
        }
    }
}

package com.controlhub.app.apkhost;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Feature #45 — Hosted-app registry
 * Ek row = ek APK jo import kiya gaya (Feature #44 se) — uska metadata aur
 * validation status.
 */
@Entity(tableName = "hosted_apks")
public class HostedApkEntity {

    @PrimaryKey(autoGenerate = true)
    public long id;

    public String packageName;
    public String label;
    public String versionName;
    public int versionCode;
    public String storedFilePath; // app-private storage mein kahan rakha gaya
    public int minSdkVersion;     // Feature #48 — compatibility check ke liye
    public boolean validated;
    public String lastError;      // agar validation fail hui to kyun (null agar sab theek)
    public long importedAt;

    public HostedApkEntity(String packageName, String label, String versionName, int versionCode,
                            String storedFilePath, int minSdkVersion, boolean validated,
                            String lastError, long importedAt) {
        this.packageName = packageName;
        this.label = label;
        this.versionName = versionName;
        this.versionCode = versionCode;
        this.storedFilePath = storedFilePath;
        this.minSdkVersion = minSdkVersion;
        this.validated = validated;
        this.lastError = lastError;
        this.importedAt = importedAt;
    }
}

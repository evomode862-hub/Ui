package com.controlhub.app.filetransfer;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/**
 * Step 5 — File transfer policy (PURE JAVA, android.* nahi): size limit + khatarnaak file types.
 *
 *  - maxBytes (default 100 MB): isse badi file reject (HTTP 413)
 *  - blocked extensions (apk, exe, sh, jar, ...): phone par incoming file ke liye reject (HTTP 415).
 *    Double-extension trick ("invoice.apk.pdf") bhi pakda jaata hai — naam ka koi bhi hissa blocked ho to reject.
 *  - mimeFor(): extension se MIME type (sirf report ke liye, security decision nahi)
 */
public class FilePolicy {

    public static final long DEFAULT_MAX_BYTES = 100L * 1024 * 1024;
    private static final int MAX_NAME_LENGTH = 200;

    /** Transfer reject hui — status = HTTP code (413 size, 415 type, 422 checksum, 429 zyada transfers, 507 storage) */
    public static class Rejected extends RuntimeException {
        public final int status;

        public Rejected(int status, String message) {
            super(message);
            this.status = status;
        }
    }

    private final long maxBytes;
    private final Set<String> blockedExtensions;

    public FilePolicy(long maxBytes, Set<String> blockedExtensions) {
        this.maxBytes = maxBytes;
        this.blockedExtensions = blockedExtensions;
    }

    public static FilePolicy defaults() {
        return new FilePolicy(DEFAULT_MAX_BYTES, new HashSet<>(Arrays.asList(
                "apk", "apks", "xapk", "aab", "exe", "msi", "dll", "bat", "cmd", "com", "scr", "pif",
                "sh", "bash", "ps1", "vbs", "jar", "dex", "so", "lnk", "reg", "dmg")));
    }

    public long maxBytes() {
        return maxBytes;
    }

    public void checkSize(long totalBytes) {
        if (totalBytes > maxBytes) {
            throw new Rejected(413, "File too large: " + totalBytes + " bytes (limit " + maxBytes + ")");
        }
    }

    public void checkName(String fileName) {
        if (fileName == null || fileName.isEmpty()) {
            throw new IllegalArgumentException("fileName is required");
        }
        if (fileName.length() > MAX_NAME_LENGTH) {
            throw new IllegalArgumentException("fileName too long (max " + MAX_NAME_LENGTH + ")");
        }
        for (int i = 0; i < fileName.length(); i++) {
            if (fileName.charAt(i) < 0x20) {
                throw new IllegalArgumentException("fileName has control characters");
            }
        }
        String lower = fileName.toLowerCase(Locale.ROOT);
        String[] parts = lower.split("\\.");
        for (int i = 1; i < parts.length; i++) { // parts[0] = base naam, baaki extensions
            if (blockedExtensions.contains(parts[i])) {
                throw new Rejected(415, "File type not allowed: ." + parts[i]);
            }
        }
    }

    public void check(String fileName, long totalBytes) {
        checkName(fileName);
        checkSize(totalBytes);
    }

    public static String mimeFor(String fileName) {
        String n = fileName == null ? "" : fileName.toLowerCase(Locale.ROOT);
        int dot = n.lastIndexOf('.');
        String ext = dot >= 0 ? n.substring(dot + 1) : "";
        switch (ext) {
            case "txt": case "log": return "text/plain";
            case "csv": return "text/csv";
            case "json": return "application/json";
            case "xml": return "application/xml";
            case "html": case "htm": return "text/html";
            case "pdf": return "application/pdf";
            case "png": return "image/png";
            case "jpg": case "jpeg": return "image/jpeg";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "mp3": return "audio/mpeg";
            case "mp4": return "video/mp4";
            case "zip": return "application/zip";
            case "doc": return "application/msword";
            case "docx": return "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
            case "xls": return "application/vnd.ms-excel";
            case "xlsx": return "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            default: return "application/octet-stream";
        }
    }
}

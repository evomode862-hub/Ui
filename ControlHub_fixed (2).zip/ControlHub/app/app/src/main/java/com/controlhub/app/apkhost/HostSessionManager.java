package com.controlhub.app.apkhost;

import android.content.Context;

import com.controlhub.app.security.AuditLogger;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Feature #46 — Container/session management (basic version)
 *
 * IMPORTANT (honest note): "Session" yahan ek real isolated container nahi
 * hai — Android normal APIs se ye possible nahi (RuntimeAdapter ke class-level
 * note mein wajah likhi hai). Ye sirf bookkeeping hai: "kaunsa APK, kab launch
 * hua, abhi active hai ya nahi" — future mein agar koi real runtime adapter
 * banaya jaaye, wahi is session-tracking structure ko reuse kar sakta hai.
 */
public class HostSessionManager {

    public static class Session {
        public final String sessionId;
        public final String packageName;
        public final long startedAt;
        public volatile boolean active;

        Session(String sessionId, String packageName, long startedAt) {
            this.sessionId = sessionId;
            this.packageName = packageName;
            this.startedAt = startedAt;
            this.active = true;
        }
    }

    private static final Map<String, Session> activeSessions = new ConcurrentHashMap<>();

    public static Session startSession(Context context, String packageName) {
        String sessionId = UUID.randomUUID().toString();
        Session session = new Session(sessionId, packageName, System.currentTimeMillis());
        activeSessions.put(sessionId, session);

        AuditLogger.info(context, "APK Host session started: " + sessionId + " for " + packageName);
        return session;
    }

    public static void endSession(Context context, String sessionId) {
        Session session = activeSessions.get(sessionId);
        if (session != null) {
            session.active = false;
            activeSessions.remove(sessionId);
            AuditLogger.info(context, "APK Host session ended: " + sessionId);
        }
    }

    public static Session getSession(String sessionId) {
        return activeSessions.get(sessionId);
    }

    public static Map<String, Session> getActiveSessions() {
        return activeSessions;
    }
}

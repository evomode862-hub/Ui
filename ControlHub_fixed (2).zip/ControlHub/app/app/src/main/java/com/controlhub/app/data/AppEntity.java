package com.controlhub.app.data;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

/**
 * Feature #3 — Local database
 * Ek row = ek installed app ka record (Stage 2 mein Installed Apps Manager isko use karega)
 */
@Entity(tableName = "apps")
public class AppEntity {

    @PrimaryKey
    @NonNull
    public String packageName;

    public String appLabel;
    public boolean isRunning;
    public long lastSeenAt;

    public AppEntity(@NonNull String packageName, String appLabel, boolean isRunning, long lastSeenAt) {
        this.packageName = packageName;
        this.appLabel = appLabel;
        this.isRunning = isRunning;
        this.lastSeenAt = lastSeenAt;
    }
}

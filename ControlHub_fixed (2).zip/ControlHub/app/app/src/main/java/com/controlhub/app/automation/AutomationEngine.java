package com.controlhub.app.automation;

import android.content.Context;
import android.util.Log;

import com.controlhub.app.accessibility.ControlHubAccessibilityService;
import com.controlhub.app.data.AppDatabase;
import com.controlhub.app.data.TaskDao;
import com.controlhub.app.data.TaskEntity;
import com.controlhub.app.events.EventBus;
import com.controlhub.app.security.AuditLogger;
import com.controlhub.app.security.EmergencyStopManager;
import com.controlhub.app.service.DeviceState;
import com.controlhub.app.apps.InstalledAppsManager;

import java.util.List;

/**
 * Feature #31 — Observe, #32 — Reason, #33 — Act, #34 — Verify, #35 — Escalation
 *
 * Step 3:
 *  - Selectors (id/desc/text/hierarchy/xy) + confidence, post-condition verify (polling)
 *  - Recovery ladder: re-observe -> scroll karke dhoondo (max 2) -> alternate selector -> escalate
 *  - Har step ka evidence audit log mein (action type, selector kind, result, note) — typed text ya
 *    message content KABHI nahi likha jata
 *  - Escalation par "task.needs_attention" event
 *
 * Honest note: "alternate candidate" retry us halat mein double-click kar sakta hai jab pehla click
 * asal mein chal gaya tha par verify galat fail hua. Isliye critical buttons (jaise Send) par
 * explicit post-condition ("=> gone:..." / "=> appears:...") zaroor do.
 */
public class AutomationEngine {

    private static final String TAG = "AutomationEngine";
    private static final int MAX_ATTEMPTS = 60;
    private static final int MAX_FAILURES_PER_STEP = 3;
    private static final long SETTLE_MS = 300;

    private final AutomationReasoner reasoner = new AutomationReasoner();
    private final AutomationExecutor executor = new AutomationExecutor();
    private final AutomationVerifier verifier = new AutomationVerifier();

    public void runTask(Context context, long taskId) {
        Context app = context.getApplicationContext();
        TaskDao dao = AppDatabase.getInstance(app).taskDao();

        if (dao.markRunning(taskId, System.currentTimeMillis()) == 0) {
            Log.i(TAG, "Task " + taskId + " not runnable (paused/terminal/missing) — skipping");
            return;
        }
        TaskEntity task = dao.getById(taskId);
        if (task == null) return;

        List<AutomationCommand> commands;
        try {
            commands = AutomationReasoner.parse(task.instructions);
        } catch (IllegalArgumentException e) {
            escalate(app, dao, taskId, 0, "Invalid instructions: " + e.getMessage());
            return;
        }

        int stepIndex = task.currentStep; // checkpoint se resume
        AuditLogger.info(app, "Task " + taskId + " running (resume from command #" + stepIndex + " of " + commands.size() + ")");
        EventBus.publish("task.progress", "taskId", taskId);

        RecoveryContext rc = new RecoveryContext();
        int attempts = 0;

        while (attempts < MAX_ATTEMPTS) {
            attempts++;

            if (EmergencyStopManager.isStopped()) {
                dao.markCancelled(taskId, System.currentTimeMillis());
                AuditLogger.warning(app, "Task " + taskId + " cancelled — emergency stop");
                return;
            }

            TaskEntity fresh = dao.getById(taskId);
            if (fresh == null || !"running".equals(fresh.status)) {
                Log.i(TAG, "Task " + taskId + " is now " + (fresh == null ? "missing" : fresh.status) + " — stopping loop");
                if (fresh != null && "cancelled".equals(fresh.status)) {
                    rollbackUnsentInput(app, commands, stepIndex, fresh.mode); // user ne cancel kiya
                    restoreForeground(app, fresh);
                    dao.redactFinishedFlagged();
                }
                return;
            }
            if (fresh.deadlineAt > 0 && System.currentTimeMillis() > fresh.deadlineAt) {
                escalate(app, dao, taskId, stepIndex, "Deadline exceeded");
                return;
            }

            // Observe
            AutomationObserver.ObservedState before = AutomationObserver.observe();
            // Background (Mode A) tasks ko accessibility ki zaroorat nahi (sirf notification reply)
            if (!before.accessibilityAvailable && !"background".equals(fresh.mode)) {
                escalate(app, dao, taskId, stepIndex, "Accessibility Service is not running — cannot observe screen");
                return;
            }

            // Reason
            AutomationStep step = reasoner.decide(before, commands, stepIndex, rc);
            Log.i(TAG, "Attempt " + attempts + ", command #" + stepIndex + ": " + step.type + " (" + step.reason + ")");

            if (step.type == AutomationStep.Type.DONE) {
                if (dao.markDone(taskId, System.currentTimeMillis()) > 0) {
                    AuditLogger.info(app, "Task " + taskId + " done: " + step.reason);
                    EventBus.publish("task.complete", "taskId", taskId);
                    restoreForeground(app, dao.getById(taskId));
                    dao.redactFinishedFlagged();
                }
                return;
            }
            if (step.type == AutomationStep.Type.FAIL) {
                escalate(app, dao, taskId, stepIndex, "Cannot proceed: " + step.reason);
                return;
            }

            // Mode B guard: UI chalane se pehle phone usable hona chahiye (screen on + unlocked)
            if (step.isUi()) {
                String blocked = DeviceState.uiBlockedReason(app);
                if (blocked != null) {
                    escalate(app, dao, taskId, stepIndex, "Foreground (UI) mode cannot run: " + blocked);
                    return;
                }
                // Step 7: battery awareness — <=10% aur charging nahi to UI automation ruk jaati hai
                String lowBattery = DeviceState.lowBatteryReason(app);
                if (lowBattery != null) {
                    escalate(app, dao, taskId, stepIndex, "Foreground (UI) automation paused to protect the phone: " + lowBattery);
                    return;
                }
            }

            // Step 8: pehle UI step se pehle batao user kis app mein tha (rollback ke liye)
            if (step.isUi() && fresh.startPackage != null && fresh.startPackage.isEmpty()
                    && before.foregroundPackage != null && !before.foregroundPackage.isEmpty()) {
                dao.setStartPackage(taskId, before.foregroundPackage, System.currentTimeMillis());
                fresh.startPackage = before.foregroundPackage;
            }

            // Act
            AutomationExecutor.ExecutionResult result = executor.execute(app, step);

            // Recovery action (scroll): command aage nahi badhta, sirf dobara observe
            if (step.recovery) {
                rc.scrollsTried++;
                evidence(app, taskId, stepIndex, step, result.success, "recovery: " + result.message);
                settle();
                continue;
            }

            if (!result.success) {
                rc.failuresOnStep++;
                dao.incrementRetry(taskId, System.currentTimeMillis(), "act: " + result.message);
                evidence(app, taskId, stepIndex, step, false, "act failed: " + result.message);
                if (rc.failuresOnStep >= MAX_FAILURES_PER_STEP) {
                    escalate(app, dao, taskId, stepIndex, "Action failed " + rc.failuresOnStep + "x: " + result.message);
                    return;
                }
                settle();
                continue;
            }

            // Verify
            AutomationVerifier.VerifyResult vr = verifier.verify(before, step);
            if (!vr.passed && step.type == AutomationStep.Type.REPLY) {
                // Reply bhej di gayi thi — dobara bhejne se duplicate message jayega. Seedha escalate.
                evidence(app, taskId, stepIndex, step, false, "verify failed: " + vr.note);
                escalate(app, dao, taskId, stepIndex, "Reply was sent but could not be confirmed — check the chat manually (not retried to avoid duplicates)");
                return;
            }
            if (!vr.passed) {
                rc.failuresOnStep++;
                dao.incrementRetry(taskId, System.currentTimeMillis(), "verify: " + vr.note);
                evidence(app, taskId, stepIndex, step, false, "verify failed: " + vr.note);
                if (rc.failuresOnStep >= MAX_FAILURES_PER_STEP) {
                    escalate(app, dao, taskId, stepIndex, "Verification failed " + rc.failuresOnStep + "x: " + vr.note);
                    return;
                }
                settle();
                continue;
            }

            evidence(app, taskId, stepIndex, step, true, (vr.unverified ? "UNVERIFIED — " : "verified — ") + vr.note);

            // Command safal — CHECKPOINT
            rc.reset();
            stepIndex++;
            dao.updateStep(taskId, stepIndex, System.currentTimeMillis());
            EventBus.publish("task.progress", "taskId", taskId);
        }

        escalate(app, dao, taskId, stepIndex, "Reached max attempts (" + MAX_ATTEMPTS + ") without completing task");
    }

    private void settle() {
        try {
            Thread.sleep(SETTLE_MS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Privacy: sirf action type, selector kind, confidence, result — text/message content nahi */
    private void evidence(Context app, long taskId, int stepIndex, AutomationStep step, boolean ok, String note) {
        StringBuilder sb = new StringBuilder("Task ").append(taskId).append(" cmd#").append(stepIndex)
                .append(' ').append(step.type);
        if (step.type == AutomationStep.Type.TAP_ELEMENT || step.type == AutomationStep.Type.TAP_XY) {
            sb.append(" sel=").append(step.selectorKind).append(" conf=").append(String.format(java.util.Locale.US, "%.2f", step.confidence));
        } else if (step.type == AutomationStep.Type.TYPE_TEXT) {
            sb.append(" len=").append(step.text == null ? 0 : step.text.length());
        } else if (step.type == AutomationStep.Type.PRESS_KEY) {
            sb.append(" key=").append(step.text);
        } else if (step.type == AutomationStep.Type.REPLY) {
            sb.append(" pkg=").append(step.packageName).append(" len=").append(step.text == null ? 0 : step.text.length());
        } else if (step.type == AutomationStep.Type.LAUNCH_APP) {
            sb.append(' ').append(step.packageName);
        }
        sb.append(ok ? " OK: " : " FAIL: ").append(note);
        if (ok) AuditLogger.info(app, sb.toString()); else AuditLogger.warning(app, sb.toString());
    }

    /**
     * Step 7 — Limited rollback: agar task type: ke BAAD (jaise send tap par) fail ya cancel hua, aur
     * input field mein abhi bhi wahi agent-typed text pada hai, to use mita do (adhura/unsent draft na bache).
     * Sirf tab jab field ka text EXACTLY typed text ke barabar ho — user ka apna text kabhi nahi mitta.
     * Honest limit: tap/open/send jaise actions ka rollback nahi hota.
     */
    private void rollbackUnsentInput(Context app, List<AutomationCommand> commands, int stepIndex, String mode) {
        try {
            if (EmergencyStopManager.isStopped()) return; // Emergency Stop ke baad kabhi UI nahi chalate
            if (!"foreground".equals(mode) || stepIndex <= 0 || stepIndex - 1 >= commands.size()) return;
            AutomationCommand prev = commands.get(stepIndex - 1);
            if (prev.action != AutomationCommand.Action.TYPE) return;
            ControlHubAccessibilityService svc = ControlHubAccessibilityService.getInstance();
            if (svc == null || DeviceState.uiBlockedReason(app) != null) return;
            if (svc.clearFocusedInputIfEquals(prev.arg)) {
                AuditLogger.warning(app, "Rollback: cleared unsent typed text (len=" + prev.arg.length() + ")");
            }
        } catch (Throwable t) {
            Log.w(TAG, "Rollback failed", t);
        }
    }

    /**
     * Step 8 — Open-app rollback: task ne jo apps kholi unse user ko wapas uski pichli app (ya home screen) par.
     * RollbackPolicy faisla karta hai (Emergency Stop / locked screen par kabhi nahi).
     * Honest limit: app ki andar ki state (scroll position, khula chat) wapas nahi aati — sirf app level.
     */
    private void restoreForeground(Context app, TaskEntity t) {
        try {
            if (t == null) return;
            ControlHubAccessibilityService svc = ControlHubAccessibilityService.getInstance();
            if (svc == null) return;
            String launcher = InstalledAppsManager.getLauncherPackage(app);
            RollbackPolicy.Action action = RollbackPolicy.decide(t.mode, t.restoreApp, t.startPackage,
                    svc.getForegroundPackage(), launcher, app.getPackageName(),
                    EmergencyStopManager.isStopped(), DeviceState.uiBlockedReason(app) != null);
            if (action == RollbackPolicy.Action.GO_HOME) {
                svc.pressHome();
                AuditLogger.info(app, "Rollback: returned to home screen");
            } else if (action == RollbackPolicy.Action.LAUNCH_START_APP) {
                if (InstalledAppsManager.launchApp(app, t.startPackage)) {
                    AuditLogger.info(app, "Rollback: returned to " + t.startPackage);
                }
            }
        } catch (Throwable th) {
            Log.w(TAG, "restoreForeground failed", th);
        }
    }

    private void escalate(Context app, TaskDao dao, long taskId, int stepIndex, String errorMessage) {
        String full = "command #" + stepIndex + ": " + errorMessage;
        if (dao.markFailed(taskId, System.currentTimeMillis(), full) == 0) return; // pehle hi cancel/pause ho chuka
        try {
            TaskEntity t = dao.getById(taskId);
            if (t != null) {
                if (!TaskEntity.REDACTED.equals(t.instructions)) {
                    rollbackUnsentInput(app, AutomationReasoner.parse(t.instructions), stepIndex, t.mode);
                }
                restoreForeground(app, t);
            }
            dao.redactFinishedFlagged();
        } catch (Throwable ignored) {
        }
        Log.e(TAG, "Task " + taskId + " failed at " + full);
        AuditLogger.error(app, "Task " + taskId + " failed at " + full);
        EventBus.publish("task.needs_attention", "taskId", taskId);
        EventBus.publish("error", "message", "Task " + taskId + " failed: " + full);
    }
}

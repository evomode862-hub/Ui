package com.controlhub.app.automation;

import android.content.Context;

import com.controlhub.app.accessibility.ControlHubAccessibilityService;
import com.controlhub.app.apps.InstalledAppsManager;
import com.controlhub.app.notifications.ControlHubNotificationListener;
import com.controlhub.app.notifications.NotificationStore;
import com.controlhub.app.service.TaskQueueManager;

/**
 * Feature #33 — Act
 * Decided AutomationStep ko actual action mein badalta hai — Stage 5 ke
 * TaskQueueManager ke through, taaki dusre API-triggered actions ke saath
 * race na ho aur ek transient failure pe khud dobara try ho (Feature #30).
 */
public class AutomationExecutor {

    public static class ExecutionResult {
        public final boolean success;
        public final String message;

        ExecutionResult(boolean success, String message) {
            this.success = success;
            this.message = message;
        }
    }

    public ExecutionResult execute(Context context, AutomationStep step) {
        ControlHubAccessibilityService service = ControlHubAccessibilityService.getInstance();

        try {
            switch (step.type) {
                case TAP_ELEMENT:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    boolean tapped = TaskQueueManager.getInstance().submitAndWait(() ->
                            step.longPress ? service.longClickElement(step.element) : service.clickElement(step.element));
                    return new ExecutionResult(tapped, tapped ? "tapped element " + step.elementId : "element not found");

                case TAP_XY:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    TaskQueueManager.getInstance().submitAndWait(() -> {
                        if (step.longPress) service.longPress(step.x, step.y); else service.tap(step.x, step.y);
                        return true;
                    });
                    return new ExecutionResult(true, "tapped at " + step.x + "," + step.y);

                case TYPE_TEXT:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    boolean typed = TaskQueueManager.getInstance().submitAndWait(() ->
                            service.typeText(step.text));
                    return new ExecutionResult(typed, typed ? "typed text" : "no focused input field");

                case PRESS_KEY: {
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    boolean pressed = TaskQueueManager.getInstance().submitAndWait(() -> service.pressKey(step.text));
                    return new ExecutionResult(pressed, pressed ? "pressed key " + step.text
                            : "key '" + step.text + "' not available here (enter needs Android 11+ and a focused field)");
                }

                case SCROLL:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    TaskQueueManager.getInstance().submitAndWait(() -> {
                        service.scroll(step.direction);
                        return true;
                    });
                    return new ExecutionResult(true, "scrolled " + step.direction);

                case LAUNCH_APP:
                    boolean launched = TaskQueueManager.getInstance().submitAndWait(() ->
                            InstalledAppsManager.launchApp(context, step.packageName));
                    return new ExecutionResult(launched, launched ? "launched " + step.packageName : "could not launch " + step.packageName);

                case STOP_APP:
                    TaskQueueManager.getInstance().submitAndWait(() -> {
                        InstalledAppsManager.stopApp(context, step.packageName);
                        return true;
                    });
                    return new ExecutionResult(true, "requested stop for " + step.packageName);

                case PRESS_BACK:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    TaskQueueManager.getInstance().submitAndWait(() -> {
                        service.pressBack();
                        return true;
                    });
                    return new ExecutionResult(true, "pressed back");

                case PRESS_HOME:
                    if (service == null) return new ExecutionResult(false, "Accessibility service not running");
                    TaskQueueManager.getInstance().submitAndWait(() -> {
                        service.pressHome();
                        return true;
                    });
                    return new ExecutionResult(true, "pressed home");

                case REPLY: {
                    if (!ControlHubNotificationListener.isConnected()) {
                        return new ExecutionResult(false, "Notification access is not enabled/connected");
                    }
                    NotificationStore.Item item = NotificationStore.findReplyable(step.packageName, step.replyTarget);
                    if (item == null) {
                        return new ExecutionResult(false, "no reply-able notification found for that contact/key");
                    }
                    step.notificationKey = item.key;
                    step.notifPostTimeBefore = item.postTime;
                    String err = ControlHubNotificationListener.sendReply(context, item, step.text);
                    return new ExecutionResult(err == null, err == null ? "inline reply sent" : err);
                }

                case WAIT:
                    Thread.sleep(Math.max(1, Math.min(30, step.waitSeconds)) * 1000L);
                    return new ExecutionResult(true, "waited " + step.waitSeconds + "s");

                case DONE:
                    return new ExecutionResult(true, "task marked done by reasoner");

                case FAIL:
                    return new ExecutionResult(false, step.reason != null ? step.reason : "reasoner gave up");

                default:
                    return new ExecutionResult(false, "unknown step type");
            }
        } catch (Exception e) {
            return new ExecutionResult(false, "execution error: " + e.getMessage());
        }
    }
}

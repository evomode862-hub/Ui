package com.controlhub.app.sdk;

import android.content.Context;

import com.controlhub.app.security.ApiScope;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Feature #57 — Developer SDK: ek "capability" = ek kaam jo koi module expose karta hai.
 *
 * Capability register karne par usko Stage 8 ki saari suraksha AUTOMATIC milti hai:
 * token check, scope ON/OFF, HIGH_RISK par confirm:true, audit log, Emergency Stop,
 * serialized queue + timeout. Module developer ko ye sab dobara likhna nahi padta.
 */
public final class Capability {

    public enum ArgType { STRING, INTEGER, BOOLEAN }

    public static final class Arg {
        public final String name;
        public final ArgType type;
        public final boolean required;
        public final String description;

        Arg(String name, ArgType type, boolean required, String description) {
            this.name = name;
            this.type = type;
            this.required = required;
            this.description = description;
        }
    }

    /** Handler: args validate hokar aate hain. Bad input par IllegalArgumentException phenko (client ko 400 milega). */
    public interface Handler {
        JSONObject handle(Context context, JSONObject args) throws Exception;
    }

    public final String name;
    public final String description;
    public final ApiScope scope;
    public final List<Arg> args;
    public final Handler handler;

    private Capability(Builder b) {
        this.name = b.name;
        this.description = b.description;
        this.scope = b.scope;
        this.args = Collections.unmodifiableList(new ArrayList<>(b.args));
        this.handler = b.handler;
    }

    /**
     * Arguments ko schema ke against check karta hai.
     * @return null agar sab theek, warna error message
     */
    public String validate(JSONObject given) {
        for (Arg a : args) {
            boolean present = given.has(a.name) && !given.isNull(a.name);
            if (!present) {
                if (a.required) return "missing required argument '" + a.name + "'";
                continue;
            }
            Object v = given.opt(a.name);
            switch (a.type) {
                case STRING:
                    if (!(v instanceof String)) return "argument '" + a.name + "' must be a string";
                    break;
                case INTEGER:
                    if (!(v instanceof Integer || v instanceof Long)) return "argument '" + a.name + "' must be an integer";
                    break;
                case BOOLEAN:
                    if (!(v instanceof Boolean)) return "argument '" + a.name + "' must be a boolean";
                    break;
            }
        }
        java.util.Iterator<String> keys = given.keys();
        while (keys.hasNext()) {
            String k = keys.next();
            boolean known = false;
            for (Arg a : args) {
                if (a.name.equals(k)) { known = true; break; }
            }
            if (!known) return "unknown argument '" + k + "'";
        }
        return null;
    }

    public static Builder builder(String name, ApiScope scope, Handler handler) {
        return new Builder(name, scope, handler);
    }

    public static final class Builder {
        private final String name;
        private final ApiScope scope;
        private final Handler handler;
        private String description = "";
        private final List<Arg> args = new ArrayList<>();

        private Builder(String name, ApiScope scope, Handler handler) {
            this.name = name;
            this.scope = scope;
            this.handler = handler;
        }

        public Builder description(String d) {
            this.description = d == null ? "" : d;
            return this;
        }

        public Builder arg(String argName, ArgType type, boolean required, String desc) {
            this.args.add(new Arg(argName, type, required, desc == null ? "" : desc));
            return this;
        }

        public Capability build() {
            return new Capability(this);
        }
    }
}

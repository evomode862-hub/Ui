#!/usr/bin/env bash
# Android-independent Java logic ko asli JVM par test karta hai (Android classes ke chhote stubs ke saath).
# Github Actions mein:  bash tests/jvm/run.sh
# Local (agar sirf JDK ka compiler module ho):  JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main" bash tests/jvm/run.sh
set -euo pipefail
cd "$(dirname "$0")/../.."
SRC=app/app/src/main/java/com/controlhub/app
T=tests/jvm
JAVAC=${JAVAC:-javac}
OUT=$(mktemp -d)
trap 'rm -rf "$OUT"' EXIT

echo "== Automation logic (selectors, commands, reasoner, compiler, adapters, rollback policy) =="
mkdir -p "$OUT/logic"
$JAVAC -d "$OUT/logic" \
  $T/stubs/android/graphics/Rect.java $T/stubs/android/util/Log.java $T/stubs/android/content/*.java \
  $T/stubs/android/app/Notification.java $T/stubs/com/controlhub/app/accessibility/ControlHubAccessibilityService.java \
  $SRC/accessibility/UiElement.java $SRC/automation/Selector.java $SRC/automation/PostCondition.java \
  $SRC/automation/AutomationObserver.java $SRC/automation/AutomationCommand.java $SRC/automation/AutomationStep.java \
  $SRC/automation/AutomationReasoner.java $SRC/automation/RecoveryContext.java $SRC/automation/InstructionCompiler.java \
  $SRC/automation/RollbackPolicy.java $SRC/adapters/*.java $SRC/notifications/NotificationStore.java \
  $T/tests/LogicTest.java
java -cp "$OUT/logic" LogicTest

echo "== Security (rate limit, idempotency, scoped tokens) =="
mkdir -p "$OUT/sec"
$JAVAC -d "$OUT/sec" $SRC/security/RateLimiter.java $SRC/security/IdempotencyStore.java \
  $SRC/security/ScopedTokenRegistry.java $T/tests/SecurityTest.java
java -cp "$OUT/sec" SecurityTest

echo "== File transfer (SHA-256, policy, restart-resume) =="
mkdir -p "$OUT/xfer"
$JAVAC -d "$OUT/xfer" $T/stubs/org/json/*.java $SRC/filetransfer/TransferManager.java \
  $SRC/filetransfer/FilePolicy.java $T/tests/TransferTest.java
java -cp "$OUT/xfer" TransferTest

echo "ALL JVM TEST SUITES PASSED"

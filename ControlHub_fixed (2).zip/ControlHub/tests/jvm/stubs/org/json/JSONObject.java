package org.json;
import java.util.*;
public class JSONObject {
    public static final Object NULL = new Object(){ public String toString(){return "null";} };
    private final LinkedHashMap<String,Object> m = new LinkedHashMap<>();
    public JSONObject put(String k, Object v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, int v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, long v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, double v) throws JSONException { m.put(k, v); return this; }
    public JSONObject put(String k, boolean v) throws JSONException { m.put(k, v); return this; }
    public boolean has(String k){ return m.containsKey(k); }
    public Object get(String k) throws JSONException { if(!m.containsKey(k)) throw new JSONException("no "+k); return m.get(k); }
    public String getString(String k) throws JSONException { return String.valueOf(get(k)); }
    public int getInt(String k) throws JSONException { return ((Number)get(k)).intValue(); }
    public long getLong(String k) throws JSONException { return ((Number)get(k)).longValue(); }
    public boolean getBoolean(String k) throws JSONException { return (Boolean)get(k); }
    public String optString(String k, String d){ return m.containsKey(k)? String.valueOf(m.get(k)) : d; }
    public String toString(){ StringBuilder sb=new StringBuilder("{"); boolean f=true; for(Map.Entry<String,Object> e: m.entrySet()){ if(!f) sb.append(","); f=false; Object v=e.getValue(); sb.append('"').append(e.getKey()).append("\":").append(v instanceof String? "\""+v+"\"" : String.valueOf(v)); } return sb.append("}").toString(); }
}

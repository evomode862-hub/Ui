package android.content;
public interface SharedPreferences { boolean getBoolean(String k, boolean d); Editor edit(); String getString(String k,String d);
 interface Editor { Editor putBoolean(String k, boolean v); Editor putString(String k,String v); void apply(); } }

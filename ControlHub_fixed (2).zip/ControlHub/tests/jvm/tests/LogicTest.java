import com.controlhub.app.accessibility.*;
import com.controlhub.app.automation.*;
import com.controlhub.app.adapters.*;
import com.controlhub.app.notifications.NotificationStore;
import android.graphics.Rect;
import java.util.*;

public class LogicTest {
    static int pass=0, fail=0;
    static void check(boolean ok, String name){ if(ok){pass++;System.out.println("PASS  "+name);} else {fail++;System.out.println("FAIL  "+name);} }
    static UiElement el(int id,String text,String desc,String cls,String rid,boolean click,int parent,String pkg){
        UiElement e=new UiElement(id,text,cls,rid,click,false,cls.endsWith("EditText"),new Rect(id*10,id*10,id*10+50,id*10+50));
        e.contentDesc=desc; e.parentId=parent; e.packageName=pkg; return e; }
    static boolean threw(Runnable r){ try{ r.run(); return false;}catch(IllegalArgumentException e){ return true; } }

    public static void main(String[] a) throws Exception {
        // ---------- Command parsing ----------
        AutomationCommand c = AutomationCommand.parse("tap:id=send || desc=Send || xy=980,2150 => gone:id=send && text:Hello there");
        check(c.action==AutomationCommand.Action.TAP && c.selectors.size()==3 && c.conditions.size()==2, "tap with 3 alternates + 2 conditions parses");
        check(AutomationCommand.parse("type:a => b").action==AutomationCommand.Action.TYPE && AutomationCommand.parse("type:a => b").arg.equals("a => b"), "type text containing ' => ' not mistaken for a condition");
        check(AutomationCommand.parse("type:Hi => none").conditions.size()==1, "type with explicit '=> none'");
        check(AutomationCommand.parse("back").action==AutomationCommand.Action.BACK && AutomationCommand.parse("home => pkg:com.x").conditions.size()==1, "back/home parse");
        AutomationCommand rp = AutomationCommand.parse("reply:com.whatsapp|Ibrahim|Hello | world");
        check(rp.action==AutomationCommand.Action.REPLY && rp.pkg.equals("com.whatsapp") && rp.target.equals("Ibrahim") && rp.arg.equals("Hello | world") && !rp.isUi(), "reply: 3 parts, text keeps '|', not a UI command");
        check(AutomationCommand.parse("wait:5").seconds==5 && !AutomationCommand.parse("wait:5").isUi(), "wait parses");
        check(AutomationCommand.parse("open:com.x").isUi() && AutomationCommand.parse("tap:Send").isUi(), "open/tap are UI commands");
        check(threw(() -> AutomationCommand.parse("wait:99")), "wait:99 rejected");
        check(threw(() -> AutomationCommand.parse("scroll:sideways")), "bad scroll direction rejected");
        check(threw(() -> AutomationCommand.parse("tap:")), "empty tap rejected");
        check(threw(() -> AutomationCommand.parse("fly:away")), "unknown command rejected");
        check(threw(() -> AutomationCommand.parse("reply:onlytwo|parts")), "reply with 2 parts rejected");
        check(threw(() -> AutomationCommand.parse("tap:id=a => bogus:x") ) == false || true, "unknown condition tail treated as text (no crash)");
        check(threw(() -> AutomationCommand.parse("tap:nth=x")), "nth must be number");
        check(AutomationReasoner.parseCommands("a;;b\nc ;; d").size()==4, "split on ;; and newline");

        // ---------- Step 7: longtap + key ----------
        AutomationCommand lt = AutomationCommand.parse("longtap:desc=Message || has=Hello => appears:text=Copy");
        check(lt.action==AutomationCommand.Action.LONGTAP && lt.selectors.size()==2 && lt.conditions.size()==1 && lt.isUi(), "longtap parses (selectors + condition), is a UI command");
        check(AutomationCommand.parse("key:Recents").arg.equals("recents") && AutomationCommand.parse("key:enter").action==AutomationCommand.Action.KEY, "key parses (case-insensitive)");
        check(AutomationCommand.parse("key:clear").isUi(), "key is a UI command");
        check(threw(() -> AutomationCommand.parse("key:power")), "unknown key rejected");
        check(threw(() -> AutomationCommand.parse("key:")), "empty key rejected");
        check(threw(() -> AutomationCommand.parse("longtap:")), "empty longtap rejected");

        // ---------- Selector resolution ----------
        List<UiElement> screen = new ArrayList<>();
        screen.add(el(0,"","","android.widget.FrameLayout","",false,-1,"com.whatsapp"));
        screen.add(el(1,"Chats","","android.widget.TextView","com.whatsapp:id/title",false,0,"com.whatsapp"));
        screen.add(el(2,"","","android.widget.LinearLayout","com.whatsapp:id/row",true,0,"com.whatsapp"));
        screen.add(el(3,"Ibrahim","","android.widget.TextView","com.whatsapp:id/conversations_row_contact_name",false,2,"com.whatsapp"));
        screen.add(el(4,"Ibrahim","","android.widget.EditText","com.whatsapp:id/search_src_text",false,0,"com.whatsapp"));
        screen.add(el(5,"","Send","android.widget.ImageButton","com.whatsapp:id/send",true,0,"com.whatsapp"));

        List<Selector.Match> m = Selector.resolveAll(screen, Selector.parseAlternates("id=send"));
        check(m.size()==1 && m.get(0).element.elementId==5 && m.get(0).confidence==1.0, "id=send (suffix match) -> element 5, conf 1.0");
        m = Selector.resolveAll(screen, Selector.parseAlternates("desc=send"));
        check(m.size()==1 && m.get(0).element.elementId==5 && m.get(0).confidence==0.9, "desc exact (case-insens) conf 0.9");
        m = Selector.resolveAll(screen, Selector.parseAlternates("Ibrahim"));
        check(m.size()>=2, "plain text matches both TextView and EditText");
        m = Selector.resolveAll(screen, Selector.parseAlternates("cls=TextView & has=Ibrahim"));
        check(m.size()==1 && m.get(0).element.elementId==2, "cls=TextView excludes EditText; text node resolves to CLICKABLE PARENT (row 2)");
        m = Selector.resolveAll(screen, Selector.parseAlternates("has=Ibrahim & within=Chats"));
        check(m.isEmpty(), "within=Chats: no ancestor contains 'Chats' (Chats is a sibling) -> no match");
        screen.get(2).parentId=1; // row ab 'Chats' title ke andar
        m = Selector.resolveAll(screen, Selector.parseAlternates("text=Ibrahim & within=Chats"));
        check(m.size()==1, "within=Chats works when ancestor has that text");
        screen.get(2).parentId=0;
        m = Selector.resolveAll(screen, Selector.parseAlternates("xy=10,20 || id=send"));
        check(m.size()==2 && m.get(0).element!=null && m.get(1).element==null && m.get(1).x==10, "priority: id first, coordinate LAST regardless of order written");
        m = Selector.resolveAll(screen, Selector.parseAlternates("desc=Search || id=nonexistent"));
        check(m.isEmpty(), "no match -> empty list");
        m = Selector.resolveAll(screen, Selector.parseAlternates("has=Ibrahim & nth=1"));
        check(m.size()==1, "nth picks a single candidate");
        Selector expired = Selector.parseOne("id=send"); expired.expiresAt = 1;
        check(Selector.resolveAll(screen, Arrays.asList(expired)).isEmpty(), "expired selector skipped");

        // ---------- PostCondition ----------
        AutomationCommand sendCmd = AutomationCommand.parse("tap:id=send => gone:id=send && text:Ibrahim");
        com.controlhub.app.accessibility.ControlHubAccessibilityService.SCREEN = new ArrayList<>(screen);
        AutomationObserver.ObservedState st = AutomationObserver.observe();
        check(st.foregroundPackage.equals("com.whatsapp"), "observer derives foreground package");
        check(sendCmd.conditions.get(0).check(st)!=null, "gone:id=send fails while button present");
        check(sendCmd.conditions.get(1).check(st)==null, "text:Ibrahim satisfied");
        check(PostCondition.pkg("com.whatsapp").check(st)==null && PostCondition.pkg("com.other").check(st)!=null, "pkg condition");
        AutomationObserver.ObservedState st2 = AutomationObserver.observe();
        check(st.looksSameAs(st2), "same screen -> looksSameAs true");
        screen.remove(5);
        com.controlhub.app.accessibility.ControlHubAccessibilityService.SCREEN = new ArrayList<>(screen);
        AutomationObserver.ObservedState st3 = AutomationObserver.observe();
        check(!st.looksSameAs(st3), "BUG-FIX CHECK: before vs after observation are independent (screen changed -> not same)");
        check(sendCmd.conditions.get(0).check(st3)==null, "gone:id=send satisfied after button disappears");

        // ---------- Reasoner ----------
        RecoveryContext rc = new RecoveryContext();
        AutomationReasoner rs = new AutomationReasoner();
        List<AutomationCommand> cmds = AutomationReasoner.parse("tap:id=zzz\nhome");
        AutomationStep s1 = rs.decide(st3, cmds, 0, rc);
        check(s1.type==AutomationStep.Type.SCROLL && s1.recovery, "element missing -> recovery scroll");
        rc.scrollsTried=2;
        check(rs.decide(st3, cmds, 0, rc).type==AutomationStep.Type.FAIL, "after 2 scrolls -> FAIL");
        check(rs.decide(st3, cmds, 2, new RecoveryContext()).type==AutomationStep.Type.DONE, "all commands done -> DONE (old bug: never returned DONE)");
        List<AutomationCommand> two = AutomationReasoner.parse("tap:has=Ibrahim");
        AutomationStep t0 = rs.decide(st3, two, 0, new RecoveryContext());
        RecoveryContext rc1 = new RecoveryContext(); rc1.failuresOnStep=1;
        AutomationStep t1 = rs.decide(st3, two, 0, rc1);
        check(t0.type==AutomationStep.Type.TAP_ELEMENT && t1.type==AutomationStep.Type.TAP_ELEMENT, "tap steps produced");
        check(AutomationReasoner.parse("reply:*|Ibrahim|Hi").size()==1 && rs.decide(st3, AutomationReasoner.parse("reply:*|Ibrahim|Hi"),0,new RecoveryContext()).type==AutomationStep.Type.REPLY, "reply -> REPLY step");

        // ---------- Step 7: reasoner for longtap / key ----------
        List<AutomationCommand> lc = AutomationReasoner.parse("longtap:id=send");
        AutomationStep ls = rs.decide(AutomationObserver.observe(), lc, 0, new RecoveryContext());
        check(ls.type==AutomationStep.Type.SCROLL && ls.recovery, "longtap on missing element -> same recovery scroll");
        com.controlhub.app.accessibility.ControlHubAccessibilityService.SCREEN = new ArrayList<>(Arrays.asList(
            el(0,"","","android.widget.FrameLayout","",false,-1,"com.x"), el(1,"","Send","android.widget.ImageButton","com.x:id/send",true,0,"com.x")));
        ls = rs.decide(AutomationObserver.observe(), lc, 0, new RecoveryContext());
        check(ls.type==AutomationStep.Type.TAP_ELEMENT && ls.longPress, "longtap on found element -> TAP_ELEMENT with longPress=true");
        AutomationStep ts = rs.decide(AutomationObserver.observe(), AutomationReasoner.parse("tap:id=send"), 0, new RecoveryContext());
        check(ts.type==AutomationStep.Type.TAP_ELEMENT && !ts.longPress, "plain tap has longPress=false");
        AutomationStep ks = rs.decide(AutomationObserver.observe(), AutomationReasoner.parse("key:recents"), 0, new RecoveryContext());
        check(ks.type==AutomationStep.Type.PRESS_KEY && "recents".equals(ks.text) && ks.isUi(), "key -> PRESS_KEY step (UI)");
        check(AutomationReasoner.parse("reply:*|a|b").get(0).isUi()==false, "reply is not UI");
        InstructionCompiler.Result kr = InstructionCompiler.compile("key:home", "auto");
        check(kr.needsForeground, "key command requires foreground mode");
        check(threw(() -> InstructionCompiler.compile("longtap:Hello", "background")), "longtap in background mode rejected");

        // ---------- InstructionCompiler / adapters ----------
        InstructionCompiler.Result r = InstructionCompiler.compile("do:whatsapp.send_message|Ibrahim|Hello there", "foreground");
        check(r.needsForeground && r.modeUsed.equals("foreground") && r.instructions.split("\n").length==7, "whatsapp foreground macro = 7 commands");
        for (String line : r.instructions.split("\n")) AutomationCommand.parse(line); // sab valid
        check(true, "every expanded WhatsApp command parses");
        check(r.instructions.contains("type:Hello there") && r.instructions.contains("gone:id=send && text:Hello there"), "message embedded in type + verify");
        r = InstructionCompiler.compile("do:whatsapp.send_message|Ibrahim|Hello", "auto");
        check(r.needsForeground, "auto without a reply-able notification -> foreground");
        r = InstructionCompiler.compile("do:whatsapp.send_message|Ibrahim|Hello", "background");
        check(!r.needsForeground && r.modeUsed.equals("background") && r.instructions.equals("reply:com.whatsapp|Ibrahim|Hello"), "background -> single reply command");
        check(threw(() -> InstructionCompiler.compile("home", "background")), "background + UI command rejected");
        check(threw(() -> InstructionCompiler.compile("do:nope.x|a|b", "auto")), "unknown adapter rejected");
        check(threw(() -> InstructionCompiler.compile("do:whatsapp.nope|a|b", "auto")), "unknown adapter action rejected");
        check(threw(() -> InstructionCompiler.compile("do:whatsapp.send_message|Ibrahim|line1\nline2", "auto")) == false || true, "newline in message handled");
        check(threw(() -> InstructionCompiler.compile("do:whatsapp.send_message|Ib & rahim|Hi", "foreground")), "separator ' & ' in contact rejected (selector injection)");
        check(threw(() -> InstructionCompiler.compile("do:whatsapp.send_message|Ibrahim|Hi => none", "foreground")), "' => ' in message rejected (condition injection)");
        check(threw(() -> InstructionCompiler.compile("mode?", "weird")), "bad mode rejected");
        // auto + replyable notification
        NotificationStore.Item it = new NotificationStore.Item(); it.key="k1"; it.pkg="com.whatsapp"; it.title="Ibrahim"; it.hasReply=true; it.postTime=1;
        NotificationStore.put(it);
        r = InstructionCompiler.compile("do:whatsapp.send_message|ibrahim|Hello", "auto");
        check(!r.needsForeground && r.instructions.startsWith("reply:"), "auto + reply-able notification (case-insensitive title) -> background");
        check(NotificationStore.findReplyable("com.whatsapp","k1")==it, "findReplyable by exact key");
        check(NotificationStore.findReplyable("com.other","Ibrahim")==null, "package filter respected");
        it.groupSummary=true;
        check(NotificationStore.findReplyable("*","Ibrahim")==null, "group summary skipped");

        // ---------- Step 8: more adapters ----------
        for (String ad : new String[]{"telegram","instagram","messenger","signal","whatsapp","whatsapp_business"}) {
            check(AdapterRegistry.get(ad)!=null && AdapterRegistry.get(ad).status().startsWith("starter"), "adapter '"+ad+"' registered, honestly marked starter");
            InstructionCompiler.Result ar = InstructionCompiler.compile("do:"+ad+".send_message|Ali Khan|Hi there", "foreground");
            String[] lines = ar.instructions.split("\n");
            boolean allParse = true;
            for (String l : lines) { try { AutomationCommand.parse(l); } catch (RuntimeException e) { allParse=false; System.out.println("   bad: "+l+" -> "+e.getMessage()); } }
            check(lines.length==7 && allParse && ar.needsForeground, ad+": foreground macro = 7 valid commands");
            check(ar.instructions.contains("type:Ali Khan") && ar.instructions.contains("type:Hi there") && ar.instructions.contains("open:"+AdapterRegistry.get(ad).packageName()), ad+": contact + message + package embedded");
            InstructionCompiler.Result br = InstructionCompiler.compile("do:"+ad+".send_message|Ali Khan|Hi there", "background");
            check(br.instructions.equals("reply:"+AdapterRegistry.get(ad).packageName()+"|Ali Khan|Hi there") && !br.needsForeground, ad+": background = single reply command");
        }
        check(threw(() -> InstructionCompiler.compile("do:telegram.send_message|a & b|hi", "foreground")), "telegram: separator injection in contact rejected");
        check(AdapterRegistry.all().size()==6, "6 adapters total");

        // ---------- Step 8: RollbackPolicy ----------
        check(RollbackPolicy.decide("foreground", true, "com.a", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.LAUNCH_START_APP, "rollback: other app now -> relaunch start app");
        check(RollbackPolicy.decide("foreground", true, "com.launcher", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.GO_HOME, "rollback: user started on home screen -> go home");
        check(RollbackPolicy.decide("foreground", true, "com.a", "com.a", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.NONE, "rollback: already there -> nothing");
        check(RollbackPolicy.decide("foreground", true, "com.a", "com.b", "com.launcher", "com.controlhub", true, false)==RollbackPolicy.Action.NONE, "rollback: NEVER after emergency stop");
        check(RollbackPolicy.decide("foreground", true, "com.a", "com.b", "com.launcher", "com.controlhub", false, true)==RollbackPolicy.Action.NONE, "rollback: not when screen locked/off");
        check(RollbackPolicy.decide("background", true, "com.a", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.NONE, "rollback: background tasks never touch UI");
        check(RollbackPolicy.decide("foreground", false, "com.a", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.NONE, "rollback: restoreApp=false respected");
        check(RollbackPolicy.decide("foreground", true, "", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.NONE, "rollback: unknown start app -> nothing");
        check(RollbackPolicy.decide("foreground", true, "com.controlhub", "com.b", "com.launcher", "com.controlhub", false, false)==RollbackPolicy.Action.NONE, "rollback: never 'returns' into Control Hub itself");

        System.out.println("\n"+pass+" passed, "+fail+" failed");
        System.exit(fail==0?0:1);
    }
}
